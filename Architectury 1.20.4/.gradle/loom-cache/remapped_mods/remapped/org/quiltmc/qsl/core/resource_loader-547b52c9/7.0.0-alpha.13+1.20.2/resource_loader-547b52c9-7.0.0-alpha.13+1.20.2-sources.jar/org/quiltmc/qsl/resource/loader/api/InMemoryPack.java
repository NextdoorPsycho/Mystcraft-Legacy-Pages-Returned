/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.resource.loader.api;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.metadata.MetadataSectionSerializer;
import net.minecraft.server.packs.resources.IoSupplier;
import net.minecraft.util.GsonHelper;
import com.google.common.base.Suppliers;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;
import org.slf4j.Logger;
import org.quiltmc.loader.api.QuiltLoader;
import org.quiltmc.qsl.base.api.util.TriState;
import org.quiltmc.qsl.resource.loader.impl.ResourceLoaderImpl;

/**
 * Represents an in-memory resource pack.
 * <p>
 * The resources of this pack are stored in memory instead of it being on-disk.
 */
public abstract class InMemoryPack implements MutablePack {
	private static final Logger LOGGER = LogUtils.getLogger();
	private static final ExecutorService EXECUTOR_SERVICE;
	private static final boolean DUMP = TriState.fromProperty("quilt.resource_loader.debug.pack.dump_from_in_memory")
			.toBooleanOrElse(QuiltLoader.isDevelopmentEnvironment());
	private static final String VIRTUAL_ASYNC_THREADS_PROPERTY = "quilt.resource_loader.pack.virtual_async_threads";
	private final Map<ResourceLocation, Supplier<byte[]>> assets = new ConcurrentHashMap<>();
	private final Map<ResourceLocation, Supplier<byte[]>> data = new ConcurrentHashMap<>();
	private final Map<String, Supplier<byte[]>> root = new ConcurrentHashMap<>();

	@Override
	public @Nullable IoSupplier<InputStream> getRootResource(String... path) {
		String actualPath = String.join("/", path);

		return this.openResource(this.root, actualPath);
	}

	@Override
	public @Nullable IoSupplier<InputStream> getResource(PackType type, ResourceLocation id) {
		return this.openResource(this.getResourceMap(type), id);
	}

	protected <T> @Nullable IoSupplier<InputStream> openResource(Map<T, Supplier<byte[]>> map, @NotNull T key) {
		var supplier = map.get(key);

		if (supplier == null) {
			return null;
		}

		byte[] bytes = supplier.get();

		if (bytes == null) {
			return null;
		}

		return () -> new ByteArrayInputStream(bytes);
	}

	@Override
	public void listResources(PackType type, String namespace, String startingPath, ResourceOutput consumer) {
		this.getResourceMap(type).entrySet().stream()
				.filter(entry -> entry.getKey().getNamespace().equals(namespace) && entry.getKey().getPath().startsWith(startingPath))
				.forEach(entry -> {
					byte[] bytes = entry.getValue().get();

					if (bytes != null) {
						consumer.accept(entry.getKey(), () -> new ByteArrayInputStream(bytes));
					}
				});
	}

	@Override
	public @Unmodifiable Set<String> getNamespaces(PackType type) {
		return this.getResourceMap(type).keySet().stream()
				.map(ResourceLocation::getNamespace)
				.collect(Collectors.toUnmodifiableSet());
	}

	@Override
	public <T> @Nullable T getMetadataSection(MetadataSectionSerializer<T> metaReader) throws IOException {
		if (!this.root.containsKey(PackResources.PACK_META)) {
			var json = new JsonObject();
			var packJson = new JsonObject();
			packJson.addProperty("description", "A virtual resource pack.");
			packJson.addProperty("pack_format", 5); // This is like, not read by any significant system when invisible to users.
			json.add("pack", packJson);

			if (!json.has(metaReader.getMetadataSectionName())) {
				return null;
			} else {
				try {
					return metaReader.fromJson(GsonHelper.getAsJsonObject(json, metaReader.getMetadataSectionName()));
				} catch (Exception e) {
					LOGGER.error("Couldn't load {} metadata from pack \"{}\":", metaReader.getMetadataSectionName(), this.packId(), e);
					return null;
				}
			}
		}

		var resource = this.getRootResource(PackResources.PACK_META);
		if (resource == null) return null;

		try (var stream = resource.get()) {
			return ResourceLoaderImpl.parseMetadata(metaReader, this, stream);
		}
	}

	@Override
	public void close() {
		if (DUMP) {
			this.dumpAll();
		}
	}

	@Override
	public void putResource(@NotNull String fileName, byte @NotNull [] resource) {
		this.root.put(fileName, () -> resource);
	}

	@Override
	public void putResource(@NotNull PackType type, @NotNull ResourceLocation id, byte @NotNull [] resource) {
		this.getResourceMap(type).put(id, () -> resource);
	}

	@Override
	public void putResource(@NotNull String fileName, @NotNull Supplier<byte[]> resource) {
		this.root.put(fileName, Suppliers.memoize(resource::get));
	}

	@Override
	public void putResource(@NotNull PackType type, @NotNull ResourceLocation id, @NotNull Supplier<byte @NotNull []> resource) {
		this.getResourceMap(type).put(id, Suppliers.memoize(resource::get));
	}

	@Override
	public @NotNull Future<byte[]> putResourceAsync(@NotNull String fileName,
			@NotNull Function<@NotNull String, byte @NotNull []> resourceFactory) {
		Future<byte[]> future = EXECUTOR_SERVICE.submit(() -> resourceFactory.apply(fileName));
		this.putResource(fileName, () -> {
			try {
				return future.get();
			} catch (InterruptedException | ExecutionException e) {
				throw new RuntimeException(e);
			}
		});
		return future;
	}

	@Override
	public @NotNull Future<byte[]> putResourceAsync(@NotNull PackType type, @NotNull ResourceLocation id,
			@NotNull Function<@NotNull ResourceLocation, byte @NotNull []> resourceFactory) {
		Future<byte[]> future = EXECUTOR_SERVICE.submit(() -> resourceFactory.apply(id));
		this.putResource(type, id, () -> {
			try {
				return future.get();
			} catch (InterruptedException | ExecutionException e) {
				throw new RuntimeException(e);
			}
		});
		return future;
	}

	@Override
	public void clearResources(PackType type) {
		this.getResourceMap(type).clear();
	}

	@Override
	public void clearResources() {
		this.root.clear();
		this.clearResources(PackType.CLIENT_RESOURCES);
		this.clearResources(PackType.SERVER_DATA);
	}

	/**
	 * Dumps the content of this resource pack into the given path.
	 *
	 * @param path the path to dump the resources into
	 */
	public void dumpTo(@NotNull Path path) {
		try {
			Files.createDirectories(path);

			this.root.forEach((p, resource) -> this.dumpResource(path, p, resource.get()));
			this.assets.forEach((p, resource) ->
					this.dumpResource(path, QuiltPack.getResourcePath(PackType.CLIENT_RESOURCES, p), resource.get()));
			this.data.forEach((p, resource) ->
					this.dumpResource(path, QuiltPack.getResourcePath(PackType.SERVER_DATA, p), resource.get()));
		} catch (IOException e) {
			LOGGER.error("Failed to write resource pack dump from pack {} to {}.", this.packId(), path, e);
		}
	}

	protected void dumpAll() {
		this.dumpTo(Paths.get("debug", "packs", this.packId()));
	}

	protected void dumpResource(Path parentPath, String resourcePath, byte[] resource) {
		try {
			var p = parentPath.resolve(resourcePath);
			Files.createDirectories(p.getParent());
			Files.write(p, resource, StandardOpenOption.CREATE, StandardOpenOption.WRITE,
					StandardOpenOption.TRUNCATE_EXISTING);
		} catch (IOException e) {
			LOGGER.error("Failed to write resource pack dump from pack {}.", this.packId(), e);
		}
	}

	private Map<ResourceLocation, Supplier<byte[]>> getResourceMap(PackType type) {
		return switch (type) {
			case CLIENT_RESOURCES -> this.assets;
			case SERVER_DATA -> this.data;
		};
	}

	static {
		int threads = Math.max(Runtime.getRuntime().availableProcessors() / 2 - 1, 1);
		String threadsOverride = System.getProperty(VIRTUAL_ASYNC_THREADS_PROPERTY);

		if (threadsOverride != null) {
			try {
				threads = Integer.parseInt(threadsOverride);
			} catch (NumberFormatException e) {
				LOGGER.error("Could not use the number provided by the property \"{}\": ", VIRTUAL_ASYNC_THREADS_PROPERTY, e);
			}
		}

		EXECUTOR_SERVICE = Executors.newFixedThreadPool(
				threads,
				new ThreadFactoryBuilder().setDaemon(true).setNameFormat("Quilt-Resource-Loader-Virtual-Pack-Worker-%s").build()
		);
	}

	/**
	 * Represents an in-memory resource pack with a static name.
	 */
	public static class Named extends InMemoryPack {
		private final String name;

		public Named(String name) {
			this.name = name;
		}

		@Override
		public String packId() {
			return this.name;
		}
	}
}
