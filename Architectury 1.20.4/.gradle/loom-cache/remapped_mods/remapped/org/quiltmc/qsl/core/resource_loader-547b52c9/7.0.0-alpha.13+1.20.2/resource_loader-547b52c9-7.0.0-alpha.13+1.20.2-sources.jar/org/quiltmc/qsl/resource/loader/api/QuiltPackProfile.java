/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.resource.loader.api;

import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.repository.BuiltInPackSource;
import net.minecraft.server.packs.repository.Pack;
import org.jetbrains.annotations.NotNull;
import org.quiltmc.qsl.base.api.util.InjectedInterface;

/**
 * Represents a resource pack profile with extended metadata, injected into {@link Pack}.
 */
@InjectedInterface(Pack.class)
public interface QuiltPackProfile {
	/**
	 * Gets the activation type of this resource pack.
	 * <p>
	 * This may be influenced by a {@link QuiltPack#getActivationType() resource pack's activation type},
	 * but this should return {@link PackActivationType#ALWAYS_ENABLED},
	 * if {@link Pack#isRequired()} returns {@code true}.
	 *
	 * @return the activation type of this resource pack
	 */
	default @NotNull PackActivationType getActivationType() {
		return PackActivationType.NORMAL;
	}

	static Pack.ResourcesSupplier wrapToFactory(PackResources pack) {
		return BuiltInPackSource.fixedResources(pack);
	}
}
