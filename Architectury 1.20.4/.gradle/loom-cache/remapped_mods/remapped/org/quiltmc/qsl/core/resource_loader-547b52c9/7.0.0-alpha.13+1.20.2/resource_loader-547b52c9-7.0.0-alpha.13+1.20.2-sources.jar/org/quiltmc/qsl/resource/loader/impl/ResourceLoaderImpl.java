/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2021 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.resource.loader.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import com.google.gson.JsonObject;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import net.fabricmc.api.EnvType;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.metadata.MetadataSectionSerializer;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.RepositorySource;
import net.minecraft.server.packs.resources.MultiPackResourceManager;
import net.minecraft.server.packs.resources.PreparableReloadListener;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.Tuple;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.quiltmc.loader.api.ModContainer;
import org.quiltmc.loader.api.ModMetadata;
import org.quiltmc.loader.api.QuiltLoader;
import org.quiltmc.loader.api.minecraft.MinecraftQuiltLoader;
import org.quiltmc.qsl.base.api.event.Event;
import org.quiltmc.qsl.base.api.phase.PhaseData;
import org.quiltmc.qsl.base.api.phase.PhaseSorting;
import org.quiltmc.qsl.base.api.util.TriState;
import org.quiltmc.qsl.resource.loader.api.GroupPack;
import org.quiltmc.qsl.resource.loader.api.GroupPack.Wrapped;
import org.quiltmc.qsl.resource.loader.api.ResourceLoader;
import org.quiltmc.qsl.resource.loader.api.PackActivationType;
import org.quiltmc.qsl.resource.loader.api.PackRegistrationContext;
import org.quiltmc.qsl.resource.loader.api.PackRegistrationContext.Callback;
import org.quiltmc.qsl.resource.loader.api.reloader.IdentifiableResourceReloader;
import org.quiltmc.qsl.resource.loader.api.reloader.ResourceReloaderKeys;
import org.quiltmc.qsl.resource.loader.impl.ResourceReloaderPhaseData.AfterVanilla;
import org.quiltmc.qsl.resource.loader.mixin.VanillaDataPackProviderAccessor;

/**
 * Represents the implementation of the resource loader.
 */
@ApiStatus.Internal
public final class ResourceLoaderImpl implements ResourceLoader {
	private static final Map<PackType, ResourceLoaderImpl> IMPL_MAP = new EnumMap<>(PackType.class);
	/**
	 * Represents a cache of the client mod resource packs so resource packs that can cache don't lose their cache.
	 */
	private static final Map<String, List<ModNioPack>> CLIENT_MOD_RESOURCE_PACKS = new Object2ObjectOpenHashMap<>();
	/**
	 * Represents a cache of the server mod data packs so resource packs that can cache don't lose their cache.
	 */
	private static final Map<String, List<ModNioPack>> SERVER_MOD_RESOURCE_PACKS = new Object2ObjectOpenHashMap<>();
	private static final Map<String, ModNioPack> CLIENT_BUILTIN_RESOURCE_PACKS = new Object2ObjectOpenHashMap<>();
	private static final Map<String, ModNioPack> SERVER_BUILTIN_RESOURCE_PACKS = new Object2ObjectOpenHashMap<>();
	private static final Logger LOGGER = LoggerFactory.getLogger("ResourceLoader");

	private static final boolean DEBUG_RELOADERS_IDENTITY = TriState.fromProperty("quilt.resource_loader.debug.reloaders_identity")
			.toBooleanOrElse(QuiltLoader.isDevelopmentEnvironment());
	private static final boolean DEBUG_RELOADERS_ORDER = TriState.fromProperty("quilt.resource_loader.debug.reloaders_order")
			.toBooleanOrElse(false);

	private final PackType type;
	private final Set<ResourceLocation> addedReloaderIds = new ObjectOpenHashSet<>();
	private final Set<IdentifiableResourceReloader> addedReloaders = new LinkedHashSet<>();
	private final Set<Tuple<ResourceLocation, ResourceLocation>> reloadersOrdering = new LinkedHashSet<>();
	final Set<RepositorySource> resourcePackProfileProviders = new ObjectOpenHashSet<>();

	private final Event<PackRegistrationContext.Callback> defaultResourcePackRegistrationEvent = createResourcePackRegistrationEvent();
	private final Event<PackRegistrationContext.Callback> topResourcePackRegistrationEvent = createResourcePackRegistrationEvent();

	private static Event<PackRegistrationContext.Callback> createResourcePackRegistrationEvent() {
		return Event.create(PackRegistrationContext.Callback.class, callbacks -> context -> {
			for (var callback : callbacks) {
				callback.onRegisterPack(context);
			}
		});
	}

	public ResourceLoaderImpl(PackType type) {
		this.type = type;
	}

	public static ResourceLoaderImpl get(PackType type) {
		return IMPL_MAP.computeIfAbsent(type, ResourceLoaderImpl::new);
	}

	public static <T> @Nullable T parseMetadata(MetadataSectionSerializer<T> metaSectionReader, PackResources pack, InputStream inputStream) {
		JsonObject json;

		try (var reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
			json = GsonHelper.parse(reader);
		} catch (Exception e) {
			LOGGER.error("Couldn't load {} metadata from pack \"{}\":", metaSectionReader.getMetadataSectionName(), pack.packId(), e);
			return null;
		}

		if (!json.has(metaSectionReader.getMetadataSectionName())) {
			return null;
		} else {
			try {
				return metaSectionReader.fromJson(GsonHelper.getAsJsonObject(json, metaSectionReader.getMetadataSectionName()));
			} catch (Exception e) {
				LOGGER.error("Couldn't load {} metadata from pack \"{}\":", metaSectionReader.getMetadataSectionName(), pack.packId(), e);
				return null;
			}
		}
	}

	/* Resource reloaders stuff */

	public static void sort(PackType type, List<PreparableReloadListener> reloaders) {
		get(type).sort(reloaders);
	}

	@SuppressWarnings("removal")
	@Override
	public void registerReloader(@NotNull IdentifiableResourceReloader resourceReloader) {
		if (!this.addedReloaderIds.add(resourceReloader.getQuiltId())) {
			throw new IllegalStateException(
					"Tried to register resource reloader " + resourceReloader.getQuiltId() + " twice!"
			);
		}

		if (!this.addedReloaders.add(resourceReloader)) {
			throw new IllegalStateException(
					"Resource reloader with previously unknown ID " + resourceReloader.getQuiltId()
							+ " already in resource reloader set!"
			);
		}
	}

	@Override
	public void addReloaderOrdering(@NotNull ResourceLocation firstReloader, @NotNull ResourceLocation secondReloader) {
		Objects.requireNonNull(firstReloader, "The first reloader identifier should not be null.");
		Objects.requireNonNull(secondReloader, "The second reloader identifier should not be null.");

		if (firstReloader.equals(secondReloader)) {
			throw new IllegalArgumentException("Tried to add a phase that depends on itself.");
		}

		this.reloadersOrdering.add(new Tuple<>(firstReloader, secondReloader));
	}

	@Override
	public void registerPackProfileProvider(@NotNull RepositorySource provider) {
		if (!this.resourcePackProfileProviders.add(provider)) {
			throw new IllegalStateException(
					"Tried to register a resource pack profile provider twice!"
			);
		}
	}

	@Override
	public @NotNull Event<PackRegistrationContext.Callback> getRegisterDefaultPackEvent() {
		return this.defaultResourcePackRegistrationEvent;
	}

	@Override
	public @NotNull Event<PackRegistrationContext.Callback> getRegisterTopPackEvent() {
		return this.topResourcePackRegistrationEvent;
	}

	@Override
	public @NotNull PackResources newFileSystemPack(@NotNull ResourceLocation id, @NotNull ModContainer owner, @NotNull Path rootPath,
												   PackActivationType activationType, @NotNull Component displayName) {
		String name = id.getNamespace() + '/' + id.getPath();
		return new ModNioPack(name, owner.metadata(), displayName, activationType, rootPath, this.type, null);
	}

	/**
	 * Flattens the given resource pack if it's a group resource pack.
	 * <p>
	 * This is useful to flatten the resource pack list once the runtime list is figured out.
	 *
	 * @param pack     the given resource pack
	 * @param consumer the resource pack consumer
	 */
	public static void flattenPacks(PackResources pack, Consumer<PackResources> consumer) {
		if (pack instanceof GroupPack grouped) {
			grouped.streamPacks().forEach(p -> flattenPacks(p, consumer));
		} else {
			consumer.accept(pack);
		}
	}

	public void appendTopPacks(MultiPackResourceManager resourceManager, Consumer<PackResources> resourcePackAdder) {
		this.topResourcePackRegistrationEvent.invoker().onRegisterPack(new PackRegistrationContextImpl(resourceManager, resourcePackAdder));
	}

	/**
	 * Sorts the given resource reloaders to satisfy dependencies.
	 *
	 * @param reloaders the resource reloaders to sort
	 */
	private void sort(List<PreparableReloadListener> reloaders) {
		// Remove any modded reloaders to sort properly.
		reloaders.removeAll(this.addedReloaders);

		// General rules:
		// - We *do not* touch the ordering of vanilla reloaders. Ever.
		//   While dependency values are provided where possible, we cannot
		//   trust them 100%. Only code doesn't lie.
		// - We add all custom reloaders after vanilla reloaders if they don't have contrary ordering. Same reasons.

		var runtimePhases = new Object2ObjectOpenHashMap<ResourceLocation, ResourceReloaderPhaseData>();

		Iterator<PreparableReloadListener> itPhases = reloaders.iterator();
		// Add the virtual before Vanilla phase.
		ResourceReloaderPhaseData last = new ResourceReloaderPhaseData(ResourceReloaderKeys.BEFORE_VANILLA, null);
		last.setVanillaStatus(ResourceReloaderPhaseData.VanillaStatus.VANILLA);
		runtimePhases.put(last.getId(), last);

		// Add all the Vanilla reloaders.
		while (itPhases.hasNext()) {
			var currentReloader = itPhases.next();
			ResourceLocation id;

			if (currentReloader instanceof IdentifiableResourceReloader identifiable) {
				id = identifiable.getQuiltId();
			} else {
				id = new ResourceLocation("unknown",
						"private/"
								+ currentReloader.getClass().getName()
								.replace(".", "/")
								.replace("$", "_")
								.toLowerCase(Locale.ROOT)
				);

				if (DEBUG_RELOADERS_IDENTITY) {
					LOGGER.warn("The resource reloader at {} does not implement IdentifiableResourceReloader " +
							"making ordering support more difficult for other modders.", currentReloader.getClass().getName());
				}
			}

			var current = new ResourceReloaderPhaseData(id, currentReloader);
			current.setVanillaStatus(ResourceReloaderPhaseData.VanillaStatus.VANILLA);
			runtimePhases.put(id, current);

			PhaseData.link(last, current);
			last = current;
		}

		// Add the virtual after Vanilla phase.
		var afterVanilla = new ResourceReloaderPhaseData.AfterVanilla(ResourceReloaderKeys.AFTER_VANILLA);
		runtimePhases.put(afterVanilla.getId(), afterVanilla);
		PhaseData.link(last, afterVanilla);

		// Add the modded reloaders.
		for (var moddedReloader : this.addedReloaders) {
			var phase = new ResourceReloaderPhaseData(moddedReloader.getQuiltId(), moddedReloader);
			runtimePhases.put(phase.getId(), phase);
		}

		// Add the ordering.
		for (var order : this.reloadersOrdering) {
			var first = runtimePhases.get(order.getA());

			if (first == null) continue;

			var second = runtimePhases.get(order.getB());

			if (second == null) continue;

			PhaseData.link(first, second);
		}

		// Attempt to order un-ordered modded reloaders to after Vanilla to respect the rules.
		for (var putAfter : runtimePhases.values()) {
			if (putAfter == afterVanilla) continue;

			if (putAfter.vanillaStatus == ResourceReloaderPhaseData.VanillaStatus.NONE
					|| putAfter.vanillaStatus == ResourceReloaderPhaseData.VanillaStatus.AFTER) {
				PhaseData.link(afterVanilla, putAfter);
			}
		}

		// Sort the phases.
		var phases = new ArrayList<>(runtimePhases.values());
		PhaseSorting.sortPhases(phases);

		// Apply the sorting!
		reloaders.clear();

		for (var phase : phases) {
			if (phase.getData() != null) {
				reloaders.add(phase.getData());
			}
		}

		if (DEBUG_RELOADERS_ORDER) {
			LOGGER.info("Sorted reloaders: " + phases.stream().map(data -> {
				String str = data.getId().toString();

				if (data.getData() == null) {
					str += " (virtual)";
				}

				return str;
			}).collect(Collectors.joining(", ")));
		}
	}

	/* Mod resource pack stuff */

	/**
	 * Appends mod resource packs to the given list.
	 *
	 * @param packs   the resource pack list to append
	 * @param type    the type of resource
	 * @param subPath the resource pack sub path directory in mods, may be {@code null}
	 */
	public static void appendModPacks(List<PackResources> packs, PackType type, @Nullable String subPath) {
		var modResourcePacks = type == PackType.CLIENT_RESOURCES
				? CLIENT_MOD_RESOURCE_PACKS : SERVER_MOD_RESOURCE_PACKS;
		var existingList = modResourcePacks.get(subPath);
		var byMod = new Reference2ObjectOpenHashMap<ModMetadata, ModNioPack>();

		if (existingList != null) {
			for (var pack : existingList) {
				byMod.put(pack.modInfo, pack);
			}
		}

		for (var container : QuiltLoader.getAllMods()) {
			if (container.getSourceType() == ModContainer.BasicSourceType.BUILTIN) {
				continue;
			}

			if (byMod.containsKey(container.metadata())) {
				continue;
			}

			Path path = container.rootPath();

			if (subPath != null) {
				Path childPath = container.getPath(subPath).toAbsolutePath().normalize();

				if (!childPath.startsWith(path) || !Files.exists(childPath)) {
					continue;
				}

				path = childPath;
			}

			byMod.put(container.metadata(), ModNioPack.ofMod(container.metadata(), path, type));
		}

		List<ModNioPack> packList = byMod.values().stream()
				.filter(pack -> !pack.getNamespaces(type).isEmpty())
				.toList();

		// Cache the pack list for the next reload.
		modResourcePacks.put(subPath, packList);

		packs.addAll(packList);
	}

	public static GroupPack.Wrapped buildMinecraftPack(PackType type, PackResources vanillaPack) {
		// Build a list of mod resource packs.
		var packs = new ArrayList<PackResources>();
		appendModPacks(packs, type, null);

		var pack = new GroupPack.Wrapped(type, vanillaPack, packs, false);
		int[] lastExtraPackIndex = new int[] {1};

		var context = new PackRegistrationContextImpl(type, List.of(pack), p -> {
			packs.add(lastExtraPackIndex[0]++, p);
			pack.recompute();
		});

		get(type).getRegisterDefaultPackEvent().invoker().onRegisterPack(context);

		return pack;
	}

	public static GroupPack.Wrapped buildVanillaBuiltinPack(PackResources vanillaPack, PackType type, String packName) {
		// Build a list of mod resource packs.
		var packs = new ArrayList<PackResources>();
		appendModPacks(packs, type, packName);

		return new GroupPack.Wrapped(type, vanillaPack, packs, false);
	}

	/* Built-in resource packs */

	public static Component getBuiltinPackDisplayNameFromId(ResourceLocation id) {
		return Component.nullToEmpty(id.getNamespace() + "/" + id.getPath());
	}

	/**
	 * Registers a built-in resource pack. Internal implementation.
	 *
	 * @param id             the identifier of the resource pack
	 * @param subPath        the sub path in the mod resources
	 * @param container      the mod container
	 * @param activationType the activation type of the resource pack
	 * @param displayName    the display name of the resource pack
	 * @return {@code true} if successfully registered the resource pack, or {@code false} otherwise
	 * @see ResourceLoader#registerBuiltinPack(ResourceLocation, ModContainer, PackActivationType, Component)
	 */
	public static boolean registerBuiltinPack(ResourceLocation id, String subPath, ModContainer container,
			PackActivationType activationType, Component displayName) {
		Path resourcePackPath = container.getPath(subPath).toAbsolutePath().normalize();

		if (!Files.exists(resourcePackPath)) {
			return false;
		}

		var name = id.getNamespace() + "/" + id.getPath();

		boolean result = false;
		if (MinecraftQuiltLoader.getEnvironmentType() == EnvType.CLIENT) {
			result = registerBuiltinPack(PackType.CLIENT_RESOURCES,
					newBuiltinPack(container, name, displayName, resourcePackPath, PackType.CLIENT_RESOURCES, activationType)
			);
		}

		result |= registerBuiltinPack(PackType.SERVER_DATA,
				newBuiltinPack(container, name, displayName, resourcePackPath, PackType.SERVER_DATA, activationType)
		);

		return result;
	}

	private static boolean registerBuiltinPack(PackType type, ModNioPack pack) {
		if (QuiltLoader.isDevelopmentEnvironment() || !pack.getNamespaces(type).isEmpty()) {
			var builtinResourcePacks = type == PackType.CLIENT_RESOURCES
					? CLIENT_BUILTIN_RESOURCE_PACKS : SERVER_BUILTIN_RESOURCE_PACKS;
			builtinResourcePacks.put(pack.packId(), pack);
			return true;
		}
		return false;
	}

	private static ModNioPack newBuiltinPack(ModContainer container, String name, Component displayName,
			Path resourcePackPath, PackType type, PackActivationType activationType) {
		return new ModNioPack(name, container.metadata(), displayName, activationType, resourcePackPath, type, null);
	}

	public static void registerBuiltinPacks(PackType type, Consumer<Pack> profileAdder) {
		var builtinPacks = type == PackType.CLIENT_RESOURCES
				? CLIENT_BUILTIN_RESOURCE_PACKS : SERVER_BUILTIN_RESOURCE_PACKS;

		// Loop through each registered built-in resource packs and add them if valid.
		for (var entry : builtinPacks.entrySet()) {
			ModNioPack pack = entry.getValue();

			// Add the built-in pack only if namespaces for the specified resource type are present.
			if (!pack.getNamespaces(type).isEmpty()) {
				// Make the resource pack profile for built-in pack, should never be always enabled.
				var profile = ModPackUtil.makeBuiltinPackProfile(pack);

				if (profile != null) {
					profileAdder.accept(profile);
				}
			}
		}
	}

	/* Language stuff */

	/**
	 * Appends to the given map all the default language entries.
	 *
	 * @param map the language map
	 */
	public static void appendLanguageEntries(@NotNull Map<String, String> map) {
		var pack = ResourceLoaderImpl.buildMinecraftPack(PackType.CLIENT_RESOURCES,
				VanillaDataPackProviderAccessor.invokeDefaultPackBuilder()
		);

		try (var manager = new MultiPackResourceManager(PackType.CLIENT_RESOURCES, List.of(pack))) {
			for (var namespace : manager.getNamespaces()) {
				var langId = new ResourceLocation(namespace, "lang/" + Language.DEFAULT + ".json");

				for (var resource : manager.getResourceStack(langId)) {
					try (var stream = resource.open()) {
						Language.loadFromJson(stream, map::put);
					} catch (IOException e) {
						LOGGER.error("Couldn't load language file {} from pack {}.", langId, resource.sourcePackId());
					}
				}
			}
		}
	}
}
