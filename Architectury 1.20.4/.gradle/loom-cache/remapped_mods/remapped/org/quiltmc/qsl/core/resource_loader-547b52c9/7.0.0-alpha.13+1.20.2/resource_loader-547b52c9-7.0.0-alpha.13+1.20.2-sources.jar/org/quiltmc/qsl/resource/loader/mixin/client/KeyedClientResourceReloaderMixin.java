/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2021 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.resource.loader.mixin.client;

import java.util.Locale;
import net.minecraft.client.PeriodicNotificationManager;
import net.minecraft.client.gui.font.FontManager;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.GpuWarnlistManager;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.FoliageColorReloadListener;
import net.minecraft.client.resources.GrassColorReloadListener;
import net.minecraft.client.resources.MobEffectTextureManager;
import net.minecraft.client.resources.PaintingTextureManager;
import net.minecraft.client.resources.SplashManager;
import net.minecraft.client.resources.TextureAtlasHolder;
import net.minecraft.client.resources.language.LanguageManager;
import net.minecraft.client.resources.model.ModelManager;
import net.minecraft.client.searchtree.SearchRegistry;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.quiltmc.loader.api.minecraft.ClientOnly;
import org.quiltmc.qsl.resource.loader.api.reloader.IdentifiableResourceReloader;
import org.quiltmc.qsl.resource.loader.api.reloader.ResourceReloaderKeys;

@ClientOnly
@Mixin({
		/* public */
		ModelManager.class, BlockEntityRenderDispatcher.class, BlockRenderDispatcher.class, BlockEntityWithoutLevelRenderer.class,
		EntityModelSet.class, EntityRenderDispatcher.class, GrassColorReloadListener.class, FoliageColorReloadListener.class,
		FontManager.class, LanguageManager.class, ItemRenderer.class, ParticleEngine.class, PaintingTextureManager.class,
		MobEffectTextureManager.class, SoundManager.class, SplashManager.class, TextureManager.class,
		TextureAtlasHolder.class,
		/* private */
		GameRenderer.class, LevelRenderer.class, GpuWarnlistManager.class, PeriodicNotificationManager.class, SearchRegistry.class
})
public abstract class KeyedClientResourceReloaderMixin implements IdentifiableResourceReloader {
	@Unique
	private ResourceLocation quilt$id;

	@Override
	@SuppressWarnings({"ConstantConditions"})
	public @NotNull ResourceLocation getQuiltId() {
		if (this.quilt$id == null) {
			Object self = this;

			if (self instanceof ModelManager) {
				this.quilt$id = ResourceReloaderKeys.Client.MODELS;
			} else if (self instanceof BlockEntityRenderDispatcher) {
				this.quilt$id = ResourceReloaderKeys.Client.BLOCK_ENTITY_RENDERERS;
			} else if (self instanceof BlockRenderDispatcher) {
				this.quilt$id = ResourceReloaderKeys.Client.BLOCK_RENDER_MANAGER;
			} else if (self instanceof BlockEntityWithoutLevelRenderer) {
				this.quilt$id = ResourceReloaderKeys.Client.BUILTIN_ITEM_MODELS;
			} else if (self instanceof EntityModelSet) {
				this.quilt$id = ResourceReloaderKeys.Client.ENTITY_MODELS;
			} else if (self instanceof EntityRenderDispatcher) {
				this.quilt$id = ResourceReloaderKeys.Client.ENTITY_RENDERERS;
			} else if (self instanceof MobEffectTextureManager) {
				this.quilt$id = ResourceReloaderKeys.Client.STATUS_EFFECTS;
			} else if (self instanceof SoundManager) {
				this.quilt$id = ResourceReloaderKeys.Client.SOUNDS;
			} else if (self instanceof SplashManager) {
				this.quilt$id = ResourceReloaderKeys.Client.SPLASH_TEXTS;
			} else if (self instanceof LanguageManager) {
				this.quilt$id = ResourceReloaderKeys.Client.LANGUAGES;
			} else if (self instanceof TextureManager) {
				this.quilt$id = ResourceReloaderKeys.Client.TEXTURES;
			} else if (self instanceof ItemRenderer) {
				this.quilt$id = ResourceReloaderKeys.Client.ITEM_RENDERER;
			} else if (self instanceof GrassColorReloadListener) {
				this.quilt$id = ResourceReloaderKeys.Client.GRASS_COLORMAP;
			} else if (self instanceof FoliageColorReloadListener) {
				this.quilt$id = ResourceReloaderKeys.Client.FOLIAGE_COLORMAP;
			} else if (self instanceof PaintingTextureManager) {
				this.quilt$id = ResourceReloaderKeys.Client.PAINTINGS;
			} else if (self instanceof ParticleEngine) {
				this.quilt$id = ResourceReloaderKeys.Client.PARTICLES;
			} else if (self instanceof FontManager) {
				this.quilt$id = ResourceReloaderKeys.Client.FONTS;
			} else if (self instanceof TextureAtlasHolder) {
				this.quilt$id = ResourceReloaderKeys.Client.SPRITE_ATLASES;
			} else {
				this.quilt$id = new ResourceLocation("private/" + self.getClass().getSimpleName().toLowerCase(Locale.ROOT));
			}
		}

		return this.quilt$id;
	}
}
