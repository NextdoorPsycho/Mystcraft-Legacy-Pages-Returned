/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.resource.loader.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.packs.PackSelectionScreen;
import net.minecraft.client.gui.screens.packs.TransferableSelectionList;
import net.minecraft.network.chat.Component;
import org.quiltmc.loader.api.minecraft.ClientOnly;
import org.quiltmc.qsl.resource.loader.impl.BuiltinResourcePackSource;

@ClientOnly
@Mixin(PackSelectionScreen.class)
public abstract class PackScreenMixin extends Screen {
	@Shadow
	private TransferableSelectionList availablePackList;

	@Shadow
	private TransferableSelectionList selectedPackList;

	private PackScreenMixin(Component text) {
		super(text);
	}

	@SuppressWarnings("unchecked")
	@Inject(method = "render", at = @At("TAIL"))
	private void renderTooltips(GuiGraphics graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
		TransferableSelectionList.PackEntry availableEntry = this.availablePackList.getHovered();
		if (availableEntry != null) {
			if (((ResourcePackEntryAccessor) availableEntry).getPack().getPackSource() instanceof BuiltinResourcePackSource source) {
				graphics.renderTooltip(this.font, source.getTooltip(), mouseX, mouseY);
			}
		}

		TransferableSelectionList.PackEntry selectedEntry = this.selectedPackList.getHovered();
		if (selectedEntry != null) {
			if (((ResourcePackEntryAccessor) selectedEntry).getPack().getPackSource() instanceof BuiltinResourcePackSource source) {
				graphics.renderTooltip(this.font, source.getTooltip(), mouseX, mouseY);
			}
		}
	}
}
