/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.testing.api.game;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.gametest.framework.GameTestInfo;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;

/**
 * Represents Quilt-provided extensions to {@link GameTestHelper}.
 * <p>
 * This is the class that is passed in tests with default handling.
 */
public class QuiltTestContext extends GameTestHelper {
	public QuiltTestContext(GameTestInfo test) {
		super(test);
	}

	/**
	 * Expects the given block state at the given block position.
	 *
	 * @param state the expected block state
	 * @param pos   the position to check for
	 */
	public void expectBlockState(@NotNull BlockState state, @NotNull BlockPos pos) {
		this.assertBlockState(pos, s -> s.equals(state), () -> "Expected block state " + state + " at position " + pos.toShortString() + '.');
	}

	/**
	 * Uses the given item stack on the specified position.
	 *
	 * @param player  the player who uses the item
	 * @param stack   the item stack to use
	 * @param pos     the position of the use hit
	 * @param sideHit the side that's being hit for using the item
	 */
	public void useStackOnBlockAt(@NotNull Player player, @NotNull ItemStack stack, @NotNull BlockPos pos, @NotNull Direction sideHit) {
		var actualPos = this.absolutePos(pos);
		var blockHitResult = new BlockHitResult(Vec3.atCenterOf(actualPos), sideHit, actualPos, false);
		var itemUsageContext = new UseOnContext(player, InteractionHand.MAIN_HAND, blockHitResult);
		stack.useOn(itemUsageContext);
	}
}
