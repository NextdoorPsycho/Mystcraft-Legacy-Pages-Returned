/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.entity.extensions.impl;

import java.util.Collection;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.ai.village.poi.PoiRecord;
import net.minecraft.world.entity.ai.village.poi.PoiType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public interface PointOfInterestTypeExtensions {
	/**
	 * Allows adding {@link Block}s after construction.
	 *
	 * @param key The {@link ResourceKey} associated with this {@link PoiType}
	 * @param blocks all additional blocks where a {@link PoiRecord} of this type will be present.
	 *               Will apply to all of the {@link Block}'s {@link BlockState}s
	 */
	void quilt$addBlocks(ResourceKey<PoiType> key, Collection<Block> blocks);

	/**
	 * Allows adding {@link BlockState}s after construction.
	 *
	 * @param key The {@link ResourceKey} associated with this {@link PoiType}
	 * @param states all additional {@link BlockState block states} where a {@link PoiRecord} of this type will be present
	 */
	void quilt$addBlockStates(ResourceKey<PoiType> key, Collection<BlockState> states);

	/**
	 * Replaces the existing {@link PoiType#matchingStates} after construction.
	 *
	 * @param key The {@link ResourceKey} associated with this {@link PoiType}
	 * @param blocks all blocks where a {@link PoiRecord} of this type will be present.
	 *               Will apply to all of the {@link Block}'s {@link BlockState}s
	 */
	void quilt$setBlocks(ResourceKey<PoiType> key, Collection<Block> blocks);

	/**
	 * Allows replacing {@link BlockState}s after construction.
	 *
	 * @param key The {@link ResourceKey} associated with this {@link PoiType}
	 * @param states all {@link BlockState block states} where a {@link PoiRecord} of this type will be present
	 */
	void quilt$setBlockStates(ResourceKey<PoiType> key, Collection<BlockState> states);
}
