/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.entity.extensions.mixin;

import java.util.Collection;
import java.util.Set;
import net.minecraft.Util;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.ai.village.poi.PoiType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import com.google.common.collect.ImmutableSet;
import org.quiltmc.qsl.entity.extensions.impl.PointOfInterestTypeExtensions;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;


@Mixin(PoiType.class)
public class PointOfInterestTypeMixin implements PointOfInterestTypeExtensions {
	@Mutable
	@Shadow
	@Final
	private Set<BlockState> blockStates;

	@Override
	public void quilt$addBlocks(ResourceKey<PoiType> key, Collection<Block> blocks) {
		ImmutableSet.Builder<BlockState> builder = new ImmutableSet.Builder<>();

		for (Block block : blocks) {
			builder.addAll(block.getStateDefinition().getPossibleStates());
		}

		this.quilt$setBlockStates(key, builder.build(), true);
	}

	@Override
	public void quilt$addBlockStates(ResourceKey<PoiType> key, Collection<BlockState> states) {
		ImmutableSet.Builder<BlockState> builder = new ImmutableSet.Builder<>();

		builder.addAll(states);

		this.quilt$setBlockStates(key, builder.build(), true);
	}

	@Override
	public void quilt$setBlocks(ResourceKey<PoiType> key, Collection<Block> blocks) {
		ImmutableSet.Builder<BlockState> builder = new ImmutableSet.Builder<>();

		for (Block block : blocks) {
			builder.addAll(block.getStateDefinition().getPossibleStates());
		}

		this.quilt$setBlockStates(key, builder.build(), false);
	}

	@Override
	public void quilt$setBlockStates(ResourceKey<PoiType> key, Collection<BlockState> states) {
		this.quilt$setBlockStates(key, states, false);
	}

	@Unique
	private void quilt$setBlockStates(ResourceKey<PoiType> key, Collection<BlockState> states, boolean added) {
		if (!added) {
			for (BlockState state : this.blockStates) {
				PointOfInterestTypesAccessor.getStateToTypeMap().remove(state);
			}
		}

		for (BlockState state : states) {
			Holder<PoiType> replaced = PointOfInterestTypesAccessor.getStateToTypeMap().put(state, BuiltInRegistries.POINT_OF_INTEREST_TYPE.getHolderOrThrow(key));
			if (replaced != null) {
				throw Util.pauseInIde(new IllegalStateException(String.format("%s is defined in more than one PoI type: %s and %s!", state, key.location().toString(), replaced.unwrapKey().toString())));
			}
		}

		this.blockStates = Set.copyOf(states);
	}
}
