/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.entity.effect.api;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import org.jetbrains.annotations.NotNull;
import org.quiltmc.qsl.base.api.util.TriState;
import org.quiltmc.qsl.entity.effect.mixin.StatusEffectAccessor;

/**
 * Utilities for dealing with status effects.
 */
public final class StatusEffectUtils {
	private StatusEffectUtils() {
		throw new UnsupportedOperationException("StatusEffectUtils only contains static definitions.");
	}

	/**
	 * Checks if the status effect should be removed or not.
	 *
	 * @param entity the entity that has the status effect
	 * @param effect the status effect
	 * @param reason the reason the status effect should be removed
	 * @return {@code true} if the status effect should be removed, or {@code false} otherwise.
	 * @see StatusEffectEvents#SHOULD_REMOVE
	 * @see MobEffect#shouldRemove(LivingEntity, StatusEffectInstance, StatusEffectRemovalReason)
	 */
	public static boolean shouldRemove(@NotNull LivingEntity entity, @NotNull MobEffectInstance effect, @NotNull StatusEffectRemovalReason reason) {
		TriState eventResult = StatusEffectEvents.SHOULD_REMOVE.invoker().shouldRemove(entity, effect, reason);
		if (eventResult == TriState.DEFAULT) {
			return effect.getEffect().shouldRemove(entity, effect, reason);
		} else {
			return eventResult.toBooleanOrElse(false);
		}
	}

	/**
	 * Creates a new status effect by calling {@link MobEffect#class_1291(StatusEffectType, int)}.
	 *
	 * @param type  the type for the effect
	 * @param color the color for the effect
	 * @return the new effect
	 */
	public static MobEffect createEffect(MobEffectCategory type, int color) {
		return StatusEffectAccessor.invokeNew(type, color);
	}
}
