/*
 * Copyright 2016, 2017, 2018, 2019, 2020 zml and Colonel contributors
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.command.mixin;

import java.util.Set;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.quiltmc.qsl.command.impl.KnownArgTypesStorage;
import org.quiltmc.qsl.command.impl.ServerArgumentTypes;

@Mixin(ServerPlayer.class)
public abstract class ServerPlayerEntityMixin implements KnownArgTypesStorage {
	@Shadow
	public ServerGamePacketListenerImpl networkHandler;

	@Override
	public Set<ResourceLocation> quilt$getKnownArgumentTypes() {
		return ((KnownArgTypesStorage) this.networkHandler).quilt$getKnownArgumentTypes();
	}

	@Override
	public void quilt$setKnownArgumentTypes(Set<ResourceLocation> types) {
		((KnownArgTypesStorage) this.networkHandler).quilt$setKnownArgumentTypes(types);
	}

	@Inject(method = "copyFrom", at = @At("RETURN"))
	public void copyKnownArgumentTypes(ServerPlayer from, boolean alive, CallbackInfo ci) {
		this.quilt$setKnownArgumentTypes(ServerArgumentTypes.getKnownArgumentTypes(from));
	}
}
