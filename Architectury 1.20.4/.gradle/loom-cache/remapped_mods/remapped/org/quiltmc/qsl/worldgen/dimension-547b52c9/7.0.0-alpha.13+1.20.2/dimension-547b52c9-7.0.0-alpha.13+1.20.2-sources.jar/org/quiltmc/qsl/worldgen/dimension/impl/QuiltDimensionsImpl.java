/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.worldgen.dimension.impl;

import com.google.common.base.Preconditions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.portal.PortalInfo;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public class QuiltDimensionsImpl {
	// Static only-class, no instantiation necessary!
	private QuiltDimensionsImpl() {
	}

	@SuppressWarnings("unchecked")
	public static <E extends Entity> E teleport(Entity entity, ServerLevel destinationWorld, PortalInfo location) {
		Preconditions.checkArgument(
				Thread.currentThread() == entity.getServer().getRunningThread(),
				"This method may only be called from the main server thread"
		);

		var access = (EntityAccess) entity;
		access.setTeleportTarget(location);

		try {
			// Fast path for teleporting within the same dimension.
			if (entity.level() == destinationWorld) {
				if (entity instanceof ServerPlayer serverPlayerEntity) {
					serverPlayerEntity.connection.teleport(location.pos.x, location.pos.y, location.pos.z, location.yRot, entity.getXRot());
				} else {
					entity.moveTo(location.pos.x, location.pos.y, location.pos.z, location.yRot, entity.getXRot());
				}

				entity.setDeltaMovement(location.speed);
				entity.setYHeadRot(location.yRot);

				return (E) entity;
			}

			return (E) entity.changeDimension(destinationWorld);
		} finally {
			// Always clean up!
			access.setTeleportTarget(null);
		}
	}
}
