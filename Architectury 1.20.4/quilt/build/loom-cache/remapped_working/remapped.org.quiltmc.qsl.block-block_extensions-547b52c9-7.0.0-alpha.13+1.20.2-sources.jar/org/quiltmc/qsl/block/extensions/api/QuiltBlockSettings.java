/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2021 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.block.extensions.api;

import java.util.function.Function;
import java.util.function.ToIntFunction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.flag.FeatureFlag;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import org.jetbrains.annotations.Contract;
import org.quiltmc.qsl.block.extensions.mixin.AbstractBlockAccessor;
import org.quiltmc.qsl.block.extensions.mixin.AbstractBlockSettingsAccessor;

/**
 * An extended variant of the {@link BlockBehaviour.Properties} class, which provides extra methods for customization.
 */
public class QuiltBlockSettings extends BlockBehaviour.Properties {
	protected QuiltBlockSettings() {
		super();
	}

	protected QuiltBlockSettings(BlockBehaviour.Properties settings) {
		super();

		var otherAccessor = (AbstractBlockSettingsAccessor) settings;

		// region [VanillaCopy] AbstractBlock.Settings#copy(AbstractBlock.Settings)
		this.destroyTime(otherAccessor.getHardness());
		this.explosionResistance(otherAccessor.getResistance());
		this.collidable(otherAccessor.getCollidable());
		this.ticksRandomly(otherAccessor.getRandomTicks());
		this.lightLevel(otherAccessor.getLuminance());
		this.mapColor(otherAccessor.getMapColorGetter());
		this.sound(otherAccessor.getSoundGroup());
		this.friction(otherAccessor.getSlipperiness());
		this.speedFactor(otherAccessor.getVelocityMultiplier());
		this.dynamicBounds(otherAccessor.getDynamicBounds());
		this.opaque(otherAccessor.getOpaque());
		this.air(otherAccessor.getIsAir());
		this.lavaIgnitable(otherAccessor.getLavaIgnitable());
		this.liquid(otherAccessor.getLiquid());
		this.nonSolid(otherAccessor.getNonSolid());
		this.solid(otherAccessor.getSolid());
		this.pushReaction(otherAccessor.getPistonBehavior());
		this.requiresTool(otherAccessor.getToolRequired());
		((AbstractBlockSettingsAccessor) this).setOffsetFunction(otherAccessor.getOffsetFunction());
		this.spawnsDustParticles(otherAccessor.getSpawnsDustParticles());
		this.requiredFlags(otherAccessor.getRequiredFlags());
		this.emissiveRendering(otherAccessor.getEmissiveLightingPredicate());
		this.instrument(otherAccessor.getInstrument());
		this.replaceable(otherAccessor.getReplaceable());
		// endregion

		// also copy other stuff Vanilla doesn't bother with
		this.jumpFactor(otherAccessor.getJumpVelocityMultiplier());
		this.drops(otherAccessor.getLootTableId());
		this.isValidSpawn(otherAccessor.getAllowsSpawningPredicate());
		this.isRedstoneConductor(otherAccessor.getSolidBlockPredicate());
		this.isSuffocating(otherAccessor.getSuffocationPredicate());
		this.isViewBlocking(otherAccessor.getBlockVisionPredicate());
		this.hasPostProcess(otherAccessor.getPostProcessPredicate());
		this.emissiveRendering(otherAccessor.getEmissiveLightingPredicate());
	}

	/**
	 * Creates a new instance of Quilt's block settings variant.
	 *
	 * @return the new instance
	 */
	@Contract(pure = true, value = "-> new")
	public static QuiltBlockSettings of() {
		return new QuiltBlockSettings();
	}

	@Contract(pure = true, value = "!null -> new")
	public static QuiltBlockSettings copyOf(BlockBehaviour block) {
		return new QuiltBlockSettings(((AbstractBlockAccessor) block).getSettings());
	}

	@Contract(pure = true, value = "!null -> new")
	public static QuiltBlockSettings copyOf(BlockBehaviour.Properties settings) {
		return new QuiltBlockSettings(settings);
	}

	@Override
	public QuiltBlockSettings noCollission() {
		super.noCollission();
		return this;
	}

	@Override
	public QuiltBlockSettings noOcclusion() {
		super.noOcclusion();
		return this;
	}

	@Override
	public QuiltBlockSettings friction(float slipperiness) {
		super.friction(slipperiness);
		return this;
	}

	@Override
	public QuiltBlockSettings speedFactor(float velocityMultiplier) {
		super.speedFactor(velocityMultiplier);
		return this;
	}

	@Override
	public QuiltBlockSettings jumpFactor(float jumpVelocityMultiplier) {
		super.jumpFactor(jumpVelocityMultiplier);
		return this;
	}

	@Override
	public QuiltBlockSettings sound(SoundType soundGroup) {
		super.sound(soundGroup);
		return this;
	}

	@Override
	public QuiltBlockSettings lightLevel(ToIntFunction<BlockState> luminance) {
		super.lightLevel(luminance);
		return this;
	}

	@Override
	public QuiltBlockSettings strength(float hardness, float resistance) {
		super.strength(hardness, resistance);
		return this;
	}

	@Override
	public QuiltBlockSettings instabreak() {
		super.instabreak();
		return this;
	}

	@Override
	public QuiltBlockSettings strength(float strength) {
		super.strength(strength);
		return this;
	}

	@Override
	public QuiltBlockSettings randomTicks() {
		super.randomTicks();
		return this;
	}

	@Override
	public QuiltBlockSettings dynamicShape() {
		super.dynamicShape();
		return this;
	}

	@Override
	public QuiltBlockSettings noLootTable() {
		super.noLootTable();
		return this;
	}

	@Override
	public QuiltBlockSettings dropsLike(Block source) {
		super.dropsLike(source);
		return this;
	}

	@Override
	public QuiltBlockSettings ignitedByLava() {
		super.ignitedByLava();
		return this;
	}

	public QuiltBlockSettings liquid() {
		super.liquid();
		return this;
	}

	@Override
	@Contract("->this")
	public QuiltBlockSettings forceSolidOn() {
		return this.solid(true);
	}

	@Override
	@Contract("->this")
	@Deprecated
	public QuiltBlockSettings forceSolidOff() {
		return this.nonSolid(true);
	}

	@Override
	public QuiltBlockSettings pushReaction(PushReaction pistonBehavior) {
		super.pushReaction(pistonBehavior);
		return this;
	}

	@Override
	public QuiltBlockSettings air() {
		super.air();
		return this;
	}

	@Override
	public QuiltBlockSettings isValidSpawn(BlockBehaviour.StateArgumentPredicate<EntityType<?>> predicate) {
		super.isValidSpawn(predicate);
		return this;
	}

	@Override
	public QuiltBlockSettings isRedstoneConductor(BlockBehaviour.StatePredicate predicate) {
		super.isRedstoneConductor(predicate);
		return this;
	}

	@Override
	public QuiltBlockSettings isSuffocating(BlockBehaviour.StatePredicate predicate) {
		super.isSuffocating(predicate);
		return this;
	}

	@Override
	public QuiltBlockSettings isViewBlocking(BlockBehaviour.StatePredicate predicate) {
		super.isViewBlocking(predicate);
		return this;
	}

	@Override
	public QuiltBlockSettings hasPostProcess(BlockBehaviour.StatePredicate predicate) {
		super.hasPostProcess(predicate);
		return this;
	}

	@Override
	public QuiltBlockSettings emissiveRendering(BlockBehaviour.StatePredicate predicate) {
		super.emissiveRendering(predicate);
		return this;
	}

	@Override
	public QuiltBlockSettings requiresCorrectToolForDrops() {
		super.requiresCorrectToolForDrops();
		return this;
	}

	@Override
	@Contract("_->this")
	public QuiltBlockSettings mapColor(DyeColor dyeColor) {
		super.mapColor(dyeColor);
		return this;
	}

	@Override
	public QuiltBlockSettings mapColor(MapColor color) {
		super.mapColor(color);
		return this;
	}

	@Override
	@Contract("_->this")
	public QuiltBlockSettings mapColor(Function<BlockState, MapColor> function) {
		super.mapColor(function);
		return this;
	}

	@Override
	public QuiltBlockSettings destroyTime(float hardness) {
		super.destroyTime(hardness);
		return this;
	}

	@Override
	public QuiltBlockSettings explosionResistance(float resistance) {
		super.explosionResistance(resistance);
		return this;
	}

	@Override
	public QuiltBlockSettings offsetType(BlockBehaviour.OffsetType offsetType) {
		super.offsetType(offsetType);
		return this;
	}

	@Override
	public QuiltBlockSettings noTerrainParticles() {
		super.noTerrainParticles();
		return this;
	}

	@Override
	public QuiltBlockSettings requiredFeatures(FeatureFlag... flags) {
		super.requiredFeatures(flags);
		return this;
	}

	@Override
	@Contract("_->this")
	public QuiltBlockSettings instrument(NoteBlockInstrument instrument) {
		super.instrument(instrument);
		return this;
	}

	@Override
	@Contract("->this")
	public QuiltBlockSettings replaceable() {
		super.replaceable();
		return this;
	}

	// region Added by Quilt

	public QuiltBlockSettings collidable(boolean collidable) {
		((AbstractBlockSettingsAccessor) this).setCollidable(collidable);
		return this;
	}

	public QuiltBlockSettings opaque(boolean opaque) {
		((AbstractBlockSettingsAccessor) this).setOpaque(opaque);
		return this;
	}

	public QuiltBlockSettings ticksRandomly(boolean ticksRandomly) {
		((AbstractBlockSettingsAccessor) this).setRandomTicks(ticksRandomly);
		return this;
	}

	public QuiltBlockSettings dynamicBounds(boolean dynamicBounds) {
		((AbstractBlockSettingsAccessor) this).setDynamicBounds(dynamicBounds);
		return this;
	}

	public QuiltBlockSettings requiresTool(boolean requiresTool) {
		((AbstractBlockSettingsAccessor) this).setToolRequired(requiresTool);
		return this;
	}

	public QuiltBlockSettings air(boolean isAir) {
		((AbstractBlockSettingsAccessor) this).setIsAir(isAir);
		return this;
	}

	/**
	 * Sets whether this block can be set on fire by neighboring lava.
	 *
	 * @param ignitable {@code true} if this block can be set on fire by lava, or {@code false} otherwise
	 * @return {@code this} builder
	 * @see #ignitedByLava()
	 */
	public QuiltBlockSettings lavaIgnitable(boolean ignitable) {
		((AbstractBlockSettingsAccessor) this).setLavaIgnitable(ignitable);
		return this;
	}

	public QuiltBlockSettings liquid(boolean liquid) {
		((AbstractBlockSettingsAccessor) this).setLiquid(liquid);
		return this;
	}

	public QuiltBlockSettings nonSolid(boolean nonSolid) {
		((AbstractBlockSettingsAccessor) this).setNonSolid(nonSolid);
		return this;
	}

	public QuiltBlockSettings solid(boolean solid) {
		((AbstractBlockSettingsAccessor) this).setSolid(solid);
		return this;
	}

	/**
	 * Sets the luminance of the block. The block will have this luminance regardless of its current state.
	 *
	 * @param luminance new luminance
	 * @return {@code this} builder
	 * @see #lightLevel(ToIntFunction)
	 */
	public QuiltBlockSettings luminance(int luminance) {
		return this.lightLevel(ignored -> luminance);
	}

	/**
	 * Sets the loot table identifier that this block will use when broken.
	 *
	 * @param dropTableId the new loot table identifier
	 * @return {@code this} builder
	 */
	public QuiltBlockSettings drops(ResourceLocation dropTableId) {
		((AbstractBlockSettingsAccessor) this).setLootTableId(dropTableId);
		return this;
	}

	public QuiltBlockSettings spawnsDustParticles(boolean spawnsDustParticles) {
		((AbstractBlockSettingsAccessor) this).setSpawnsDustParticles(spawnsDustParticles);
		return this;
	}

	public Properties requiredFlags(FeatureFlagSet flags) {
		((AbstractBlockSettingsAccessor) this).setRequiredFlags(flags);
		return this;
	}

	public QuiltBlockSettings replaceable(boolean replaceable) {
		((AbstractBlockSettingsAccessor) this).setReplaceable(replaceable);
		return this;
	}

	// endregion
}
