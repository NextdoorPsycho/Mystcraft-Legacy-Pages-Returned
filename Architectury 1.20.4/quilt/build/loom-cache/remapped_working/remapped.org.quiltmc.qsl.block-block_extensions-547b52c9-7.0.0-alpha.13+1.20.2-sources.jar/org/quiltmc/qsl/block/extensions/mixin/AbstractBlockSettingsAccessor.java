/*
 * Copyright 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2021 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.block.extensions.mixin;

import java.util.Optional;
import java.util.function.Function;
import java.util.function.ToIntFunction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(BlockBehaviour.Properties.class)
public interface AbstractBlockSettingsAccessor {
	// region Getters
	@Accessor
	float getHardness();

	@Accessor
	float getResistance();

	@Accessor
	boolean getCollidable();

	@Accessor
	boolean getRandomTicks();

	@Accessor
	ToIntFunction<BlockState> getLuminance();

	@Accessor
	Function<BlockState, MapColor> getMapColorGetter();

	@Accessor
	SoundType getSoundGroup();

	@Accessor
	float getSlipperiness();

	@Accessor
	float getVelocityMultiplier();

	@Accessor
	float getJumpVelocityMultiplier();

	@Accessor
	boolean getDynamicBounds();

	@Accessor
	ResourceLocation getLootTableId();

	@Accessor
	boolean getOpaque();

	@Accessor
	boolean getIsAir();

	@Accessor
	boolean getLavaIgnitable();

	@Accessor
	boolean getLiquid();

	@Accessor
	boolean getNonSolid();

	@Accessor
	boolean getSolid();

	@Accessor
	PushReaction getPistonBehavior();

	@Accessor
	boolean getToolRequired();

	@Accessor
	Optional<BlockBehaviour.OffsetFunction> getOffsetFunction();

	@Accessor
	boolean getSpawnsDustParticles();

	@Accessor
	FeatureFlagSet getRequiredFlags();

	@Accessor
	BlockBehaviour.StateArgumentPredicate<EntityType<?>> getAllowsSpawningPredicate();

	@Accessor
	BlockBehaviour.StatePredicate getSolidBlockPredicate();

	@Accessor
	BlockBehaviour.StatePredicate getSuffocationPredicate();

	@Accessor
	BlockBehaviour.StatePredicate getBlockVisionPredicate();

	@Accessor
	BlockBehaviour.StatePredicate getPostProcessPredicate();

	@Accessor
	BlockBehaviour.StatePredicate getEmissiveLightingPredicate();

	@Accessor
	NoteBlockInstrument getInstrument();

	@Accessor
	boolean getReplaceable();
	// endregion

	// region Setters

	@Accessor
	void setCollidable(boolean collidable);

	@Accessor
	void setRandomTicks(boolean ticksRandomly);

	@Accessor
	void setLootTableId(ResourceLocation lootTableId);

	@Accessor
	void setOpaque(boolean opaque);

	@Accessor
	void setIsAir(boolean isAir);

	@Accessor
	void setLavaIgnitable(boolean lavaIgnitable);

	@Accessor
	void setLiquid(boolean liquid);

	@Accessor
	void setNonSolid(boolean nonSolid);

	@Accessor
	void setSolid(boolean solid);

	@Accessor
	void setToolRequired(boolean toolRequired);

	@Accessor
	void setOffsetFunction(Optional<BlockBehaviour.OffsetFunction> offsetFunction);

	@Accessor
	void setDynamicBounds(boolean dynamicBounds);

	@Accessor
	void setSpawnsDustParticles(boolean spawnsDustParticles);

	@Accessor
	void setRequiredFlags(FeatureFlagSet requiredFlags);

	@Accessor
	void setReplaceable(boolean replaceable);
	// endregion
}
