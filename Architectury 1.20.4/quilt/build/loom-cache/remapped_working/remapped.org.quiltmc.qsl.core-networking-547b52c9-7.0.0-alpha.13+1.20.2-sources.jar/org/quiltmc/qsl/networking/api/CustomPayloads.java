/*
 * Copyright 2023 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.networking.api;

import java.util.Objects;
import net.minecraft.network.ConnectionProtocol;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import org.quiltmc.qsl.networking.api.client.ClientConfigurationNetworking;
import org.quiltmc.qsl.networking.api.client.ClientPlayNetworking;
import org.quiltmc.qsl.networking.mixin.accessor.CustomPayloadC2SPacketAccessor;
import org.quiltmc.qsl.networking.mixin.accessor.CustomPayloadS2CPacketAccessor;

/**
 * Allows for registering custom payloads for between the server and client.
 * <p>
 * Note: Registering a payload does not register a receiver and vice versa.
 */
public class CustomPayloads {
	/**
	 * Registers a common ({@link net.minecraft.network.ConnectionProtocol#CONFIGURATION} or {@link net.minecraft.network.ConnectionProtocol#PLAY}) payload that is sent from the client to the server.
	 *
	 * @param type   the type or id for the payload
	 * @param reader the deserializer for the payload
	 * @param <T>    the payload type
	 * @see ClientConfigurationNetworking#registerGlobalReceiver(ResourceLocation, ClientConfigurationNetworking.CustomChannelReceiver)
	 * @see ClientPlayNetworking#registerGlobalReceiver(ResourceLocation, ClientPlayNetworking.CustomChannelReceiver)
	 */
	public static <T extends CustomPacketPayload> void registerC2SPayload(ResourceLocation type, FriendlyByteBuf.Reader<T> reader) {
		Objects.requireNonNull(type, "Type cannot be null");
		Objects.requireNonNull(reader, "Reader cannot be null");

		CustomPayloadC2SPacketAccessor.getKnownTypes().put(type, reader);
	}

	/**
	 * Registers a common ({@link ConnectionProtocol#CONFIGURATION} or {@link ConnectionProtocol#PLAY}) payload that is sent from the server to the client.
	 *
	 * @param type   the type or id for the payload
	 * @param reader the deserializer for the payload
	 * @param <T>    the payload type
	 * @see ServerConfigurationNetworking#registerGlobalReceiver(ResourceLocation, ServerConfigurationNetworking.CustomChannelReceiver)
	 * @see ServerPlayNetworking#registerGlobalReceiver(ResourceLocation, ServerPlayNetworking.CustomChannelReceiver)
	 */
	public static <T extends CustomPacketPayload> void registerS2CPayload(ResourceLocation type, FriendlyByteBuf.Reader<T> reader) {
		Objects.requireNonNull(type, "Type cannot be null");
		Objects.requireNonNull(reader, "Reader cannot be null");

		CustomPayloadS2CPacketAccessor.getKnownTypes().put(type, reader);
	}
}
