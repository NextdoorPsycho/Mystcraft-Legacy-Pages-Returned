/*
 * Copyright 2023 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.networking.impl.payload;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ResourceLocationException;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import io.netty.util.AsciiString;
import org.quiltmc.qsl.networking.impl.NetworkingImpl;

public interface ChannelPayload extends CustomPacketPayload {
	private static void write(List<ResourceLocation> channels, FriendlyByteBuf buf) {
		boolean first = true;

		for (ResourceLocation channel : channels) {
			if (first) {
				first = false;
			} else {
				buf.writeByte(0);
			}

			buf.writeBytes(channel.toString().getBytes(StandardCharsets.US_ASCII));
		}
	}

	private static List<ResourceLocation> readIds(FriendlyByteBuf buf) {
		List<ResourceLocation> ids = new ArrayList<>();
		StringBuilder active = new StringBuilder();

		while (buf.isReadable()) {
			byte b = buf.readByte();

			if (b != 0) {
				active.append(AsciiString.b2c(b));
			} else {
				addId(ids, active);
				active = new StringBuilder();
			}
		}

		addId(ids, active);

		return ids;
	}

	private static void addId(List<ResourceLocation> ids, StringBuilder sb) {
		String literal = sb.toString();

		try {
			ids.add(new ResourceLocation(literal));
		} catch (ResourceLocationException ex) {
			NetworkingImpl.LOGGER.warn("Received invalid channel identifier \"{}\"", literal);
		}
	}

	List<ResourceLocation> channels();

	record RegisterChannelPayload(List<ResourceLocation> channels) implements ChannelPayload {
		public RegisterChannelPayload(FriendlyByteBuf buf) {
			this(ChannelPayload.readIds(buf));
		}

		@Override
		public void write(FriendlyByteBuf buf) {
			ChannelPayload.write(this.channels, buf);
		}

		@Override
		public ResourceLocation id() {
			return NetworkingImpl.REGISTER_CHANNEL;
		}
	}

	record UnregisterChannelPayload(List<ResourceLocation> channels) implements ChannelPayload {
		public UnregisterChannelPayload(FriendlyByteBuf buf) {
			this(ChannelPayload.readIds(buf));
		}

		@Override
		public void write(FriendlyByteBuf buf) {
			ChannelPayload.write(this.channels, buf);
		}

		@Override
		public ResourceLocation id() {
			return NetworkingImpl.UNREGISTER_CHANNEL;
		}
	}
}
