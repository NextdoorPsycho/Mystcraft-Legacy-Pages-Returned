/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.networking.mixin;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Consumer;

import com.llamalad7.mixinextras.injector.ModifyReceiver;
import com.llamalad7.mixinextras.injector.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundDisconnectPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ConfigurationTask;
import net.minecraft.server.network.ServerCommonPacketListenerImpl;
import net.minecraft.server.network.ServerConfigurationPacketListenerImpl;
import net.minecraft.server.network.config.JoinWorldTask;
import org.quiltmc.qsl.networking.api.ServerConfigurationTaskManager;
import org.quiltmc.qsl.networking.impl.DisconnectPacketSource;
import org.quiltmc.qsl.networking.impl.NetworkHandlerExtensions;
import org.quiltmc.qsl.networking.impl.server.SendChannelsTask;
import org.quiltmc.qsl.networking.impl.server.ServerConfigurationNetworkAddon;
import org.quiltmc.qsl.networking.impl.server.ServerConfigurationPacketHandlerKnowingTask;

// We want to apply a bit earlier than other mods which may not use us in order to prevent refCount issues
@Mixin(value = ServerConfigurationPacketListenerImpl.class, priority = 900)
abstract class ServerConfigurationPacketHandlerMixin extends ServerCommonPacketListenerImpl implements NetworkHandlerExtensions, DisconnectPacketSource, ServerConfigurationTaskManager {
	@Mutable
	@Shadow
	@Final
	private Queue<ConfigurationTask> tasks;
	@Shadow
	@Nullable
	private ConfigurationTask currentTask;

	@Shadow
	protected abstract void finishCurrentTask(ConfigurationTask.Type taskType);

	@Shadow
	public abstract void startConfiguration();

	@Shadow
	protected abstract void startNextTask();

	@Unique
	private ServerConfigurationNetworkAddon addon;

	@Unique
	private boolean sentConfiguration = false;

	@Unique
	private ConfigurationTask immediateTask = null;

	@Unique
	private Queue<ConfigurationTask> priorityTasks = new ConcurrentLinkedQueue<>();

	ServerConfigurationPacketHandlerMixin(MinecraftServer server, Connection connection, CommonListenerCookie c_eyqfalbd) {
		super(server, connection, c_eyqfalbd);
	}

	@Inject(method = "<init>", at = @At("RETURN"))
	private void initAddon(CallbackInfo ci) {
		this.addon = new ServerConfigurationNetworkAddon((ServerConfigurationPacketListenerImpl) (Object) this, this.server);
		// A bit of a hack but it allows the field above to be set in case someone registers handlers during INIT event which refers to said field
		this.addon.lateInit();
	}

	@Inject(method = "startConfiguration", at = @At("HEAD"), cancellable = true)
	private void start(CallbackInfo ci) {
		if (!this.sentConfiguration) {
			this.addImmediateTask(new SendChannelsTask(this.addon));

			this.addPriorityTask(new ConfigurationTask() {
				static final Type TYPE = new Type("minecraft:start_configuration");

				@Override
				public void start(Consumer<Packet<?>> task) {
					ServerConfigurationPacketHandlerMixin.this.startConfiguration();
					ServerConfigurationPacketHandlerMixin.this.finishTask(TYPE);
				}

				@Override
				public Type type() {
					return TYPE;
				}
			});

			this.sentConfiguration = true;
			this.startNextTask();
			ci.cancel();
		}
	}

	@WrapWithCondition(method = "startConfiguration", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/ServerConfigurationPacketHandler;startNextTask()V"))
	private boolean doNotCallStart(ServerConfigurationPacketListenerImpl handler) {
		return false;
	}

	@ModifyReceiver(method = "startNextTask", at = @At(value = "INVOKE", target = "Ljava/util/Queue;poll()Ljava/lang/Object;"))
	private Queue<ConfigurationTask> modifyTaskQueue(Queue<ConfigurationTask> originalQueue) {
		if (this.immediateTask != null) {
			var singleQueue = new ConcurrentLinkedQueue<ConfigurationTask>();
			singleQueue.add(this.immediateTask);
			this.immediateTask = null;
			return singleQueue;
		}

		if (!this.priorityTasks.isEmpty()) {
			return this.priorityTasks;
		}

		return originalQueue;
	}

	@WrapOperation(method = "startConfiguration", at = @At(value = "NEW", target = "()Lnet/minecraft/network/configuration/JoinWorldConfigurationTask;"))
	private JoinWorldTask setHandlerStart(Operation<JoinWorldTask> constructor) {
		var task = constructor.call();
		((ServerConfigurationPacketHandlerKnowingTask) task).setServerConfigurationPacketHandler((ServerConfigurationPacketListenerImpl) (Object) this);
		return task;
	}

	@WrapOperation(method = "rejoinWorld", at = @At(value = "NEW", target = "()Lnet/minecraft/network/configuration/JoinWorldConfigurationTask;"))
	private JoinWorldTask setHandlerRejoin(Operation<JoinWorldTask> constructor) {
		var task = constructor.call();
		((ServerConfigurationPacketHandlerKnowingTask) task).setServerConfigurationPacketHandler((ServerConfigurationPacketListenerImpl) (Object) this);
		return task;
	}

	@Inject(method = "startNextTask", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/configuration/ConfigurationTask;start(Ljava/util/function/Consumer;)V"), locals = LocalCapture.CAPTURE_FAILHARD)
	public void beforeTaskStart(CallbackInfo ci, ConfigurationTask task) {
		this.addon.logger.debug("Starting task with type: {}", task.type());
	}

	@Inject(method = "finishCurrentTask", at = @At("HEAD"))
	public void beforeTaskStart(ConfigurationTask.Type type, CallbackInfo ci) {
		this.addon.logger.debug("Finishing task type: {}", type);
	}

	@Inject(method = "onDisconnected", at = @At("HEAD"))
	private void handleDisconnection(Component reason, CallbackInfo ci) {
		this.addon.handleDisconnect();
	}

	@Override
	public ServerConfigurationNetworkAddon getAddon() {
		return this.addon;
	}

	@Override
	public Packet<?> createDisconnectPacket(Component message) {
		return new ClientboundDisconnectPacket(message);
	}

	@Override
	public void addTask(ConfigurationTask task) {
		this.addon.logger.debug("Adding task with type: {}", task.type());
		this.tasks.add(task);
	}

	@Override
	public void addPriorityTask(ConfigurationTask task) {
		this.addon.logger.debug("Adding priority task with type: {}", task.type());
		this.priorityTasks.add(task);
	}

	@Override
	public void addImmediateTask(ConfigurationTask task) {
		this.addon.logger.debug("Adding immediate task with type: {}", task.type());

		if (this.immediateTask != null) {
			throw new RuntimeException(
				"Cannot add an immediate task of type: \"" + task.type()
				+ "\" when there is already an immediate task of type: \"" + this.immediateTask.type() + "\"."
			);
		}

		this.immediateTask = task;
	}

	@Override
	public void finishTask(ConfigurationTask.Type type) {
		this.finishCurrentTask(type);
	}

	@Nullable
	@Override
	public ConfigurationTask getCurrentTask() {
		return this.currentTask;
	}
}
