/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.networking.mixin.client;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientHandshakePacketListenerImpl;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.login.ClientboundCustomQueryPacket;
import org.quiltmc.loader.api.minecraft.ClientOnly;
import org.quiltmc.qsl.networking.impl.NetworkHandlerExtensions;
import org.quiltmc.qsl.networking.impl.client.ClientLoginNetworkAddon;
import org.quiltmc.qsl.networking.impl.payload.PacketByteBufLoginQueryRequestPayload;

@ClientOnly
@Mixin(ClientHandshakePacketListenerImpl.class)
abstract class ClientLoginNetworkHandlerMixin implements NetworkHandlerExtensions {
	@Shadow
	@Final
	private Minecraft client;

	@Unique
	private ClientLoginNetworkAddon addon;

	@Inject(method = "<init>", at = @At("RETURN"))
	private void initAddon(CallbackInfo ci) {
		this.addon = new ClientLoginNetworkAddon((ClientHandshakePacketListenerImpl) (Object) this, this.client);
	}

	@Inject(
			method = "onLoginQueryRequest",
			at = @At(value = "INVOKE", target = "Ljava/util/function/Consumer;accept(Ljava/lang/Object;)V", remap = false, shift = At.Shift.AFTER),
			cancellable = true
	)
	private void handleQueryRequest(ClientboundCustomQueryPacket packet, CallbackInfo ci) {
		if (packet.payload() instanceof PacketByteBufLoginQueryRequestPayload payload) {
			if (this.addon.handlePacket(packet)) {
				ci.cancel();
			} else {
				payload.data().skipBytes(payload.data().readableBytes());
			}
		}
	}

	@Inject(method = "onDisconnected", at = @At("HEAD"))
	private void invokeLoginDisconnectEvent(Component reason, CallbackInfo ci) {
		this.addon.handleDisconnect();
	}

	@Inject(method = "onLoginSuccess", at = @At("HEAD"))
	private void handlePlayTransition(CallbackInfo ci) {
		this.addon.handlePlayTransition();
	}

	@Override
	public ClientLoginNetworkAddon getAddon() {
		return this.addon;
	}
}
