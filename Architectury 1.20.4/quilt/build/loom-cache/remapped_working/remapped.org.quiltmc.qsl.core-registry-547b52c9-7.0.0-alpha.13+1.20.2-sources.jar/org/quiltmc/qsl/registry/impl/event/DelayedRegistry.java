/*
 * Copyright 2021 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.registry.impl.event;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Queue;
import java.util.Set;
import java.util.stream.Stream;
import net.minecraft.core.Holder;
import net.minecraft.core.Holder.Reference;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.HolderLookup.RegistryLookup;
import net.minecraft.core.HolderOwner;
import net.minecraft.core.HolderSet.Named;
import net.minecraft.core.Registry;
import net.minecraft.core.WritableRegistry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Lifecycle;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

@ApiStatus.Internal
public final class DelayedRegistry<T> implements WritableRegistry<T> {
	private final WritableRegistry<T> wrapped;
	private final Queue<DelayedEntry<T>> delayedEntries = new LinkedList<>();

	DelayedRegistry(WritableRegistry<T> registry) {
		this.wrapped = registry;
	}

	@Override
	public @Nullable ResourceLocation getKey(T entry) {
		return this.wrapped.getKey(entry);
	}

	@Override
	public Optional<ResourceKey<T>> getResourceKey(T entry) {
		return this.wrapped.getResourceKey(entry);
	}

	@Override
	public int getId(@Nullable T entry) {
		return this.wrapped.getId(entry);
	}

	@Override
	public @Nullable T get(@Nullable ResourceKey<T> entry) {
		return this.wrapped.get(entry);
	}

	@Override
	public @Nullable T get(@Nullable ResourceLocation id) {
		return this.wrapped.get(id);
	}

	@Override
	public Lifecycle lifecycle(T entry) {
		return this.wrapped.lifecycle(entry);
	}

	@Override
	public Lifecycle registryLifecycle() {
		return this.wrapped.registryLifecycle();
	}

	@Override
	public Set<ResourceLocation> keySet() {
		return this.wrapped.keySet();
	}

	@Override
	public Set<Entry<ResourceKey<T>, T>> entrySet() {
		return this.wrapped.entrySet();
	}

	@Override
	public Set<ResourceKey<T>> registryKeySet() {
		return this.wrapped.registryKeySet();
	}

	@Override
	public Optional<Reference<T>> getRandom(RandomSource random) {
		return this.wrapped.getRandom(random);
	}

	@Override
	public boolean containsKey(ResourceLocation id) {
		return this.wrapped.containsKey(id);
	}

	@Override
	public boolean containsKey(ResourceKey<T> key) {
		return this.wrapped.containsKey(key);
	}

	@Override
	public Registry<T> freeze() {
		// Refuse freezing.
		return this;
	}

	@Override
	public Reference<T> createIntrusiveHolder(T holder) {
		return this.wrapped.createIntrusiveHolder(holder);
	}

	@Override
	public Optional<Reference<T>> getHolder(int index) {
		return this.wrapped.getHolder(index);
	}

	@Override
	public Optional<Reference<T>> getHolder(ResourceKey<T> key) {
		return this.wrapped.getHolder(key);
	}

	@Override
	public Holder<T> wrapAsHolder(T object) {
		return this.wrapped.wrapAsHolder(object);
	}

	@Override
	public Stream<Reference<T>> holders() {
		return this.wrapped.holders();
	}

	@Override
	public Optional<Named<T>> getTag(TagKey<T> tag) {
		return this.wrapped.getTag(tag);
	}

	@Override
	public Named<T> getOrCreateTag(TagKey<T> key) {
		return this.wrapped.getOrCreateTag(key);
	}

	@Override
	public Stream<Pair<TagKey<T>, Named<T>>> getTags() {
		return this.wrapped.getTags();
	}

	@Override
	public Stream<TagKey<T>> getTagNames() {
		return this.wrapped.getTagNames();
	}

	@Override
	public void resetTags() {
		throw new UnsupportedOperationException("DelayedRegistry does not support resetTags.");
	}

	@Override
	public void bindTags(Map<TagKey<T>, List<Holder<T>>> tags) {
		throw new UnsupportedOperationException("DelayedRegistry does not support bindTags.");
	}

	@Override
	public HolderOwner<T> holderOwner() {
		return this.wrapped.holderOwner();
	}

	@Override
	public RegistryLookup<T> asLookup() {
		return this.wrapped.asLookup();
	}

	@Override
	public Iterator<T> iterator() {
		return this.wrapped.iterator();
	}

	@Override
	public @Nullable T byId(int index) {
		return this.wrapped.byId(index);
	}

	@Override
	public ResourceKey<? extends Registry<T>> key() {
		return this.wrapped.key();
	}

	@Override
	public int size() {
		return this.wrapped.size();
	}

	@Override
	public Reference<T> register(ResourceKey<T> key, T entry, Lifecycle lifecycle) {
		this.delayedEntries.add(new DelayedEntry<>(key, entry, lifecycle));
		return Holder.Reference.createStandAlone(this.wrapped.holderOwner(), key);
	}

	@Override
	public boolean isEmpty() {
		return this.wrapped.isEmpty();
	}

	@Override
	public HolderGetter<T> createRegistrationLookup() {
		return this.wrapped.createRegistrationLookup();
	}

	void applyDelayed() {
		DelayedEntry<T> entry;

		while ((entry = this.delayedEntries.poll()) != null) {
			this.wrapped.register(entry.key(), entry.entry(), entry.lifecycle());
		}
	}

	record DelayedEntry<T>(ResourceKey<T> key, T entry, Lifecycle lifecycle) {}
}
