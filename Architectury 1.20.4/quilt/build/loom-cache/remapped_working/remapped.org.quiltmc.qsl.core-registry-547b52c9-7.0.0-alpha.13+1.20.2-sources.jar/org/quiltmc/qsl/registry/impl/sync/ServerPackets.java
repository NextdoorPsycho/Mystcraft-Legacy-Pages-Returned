/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.registry.impl.sync;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import B;
import I;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap.Entry;
import it.unimi.dsi.fastutil.ints.IntList;
import org.jetbrains.annotations.ApiStatus;
import org.quiltmc.qsl.registry.impl.sync.mod_protocol.ModProtocolDef;
import org.quiltmc.qsl.registry.impl.sync.registry.RegistryFlag;
import org.quiltmc.qsl.registry.impl.sync.registry.SynchronizedRegistry;
import org.quiltmc.qsl.registry.impl.sync.registry.SynchronizedRegistry.SyncEntry;

/**
 * Identifiers of packets sent by server.
 */
@ApiStatus.Internal
public final class ServerPackets {
	/**
	 * Starts registry sync.
	 *
	 * <pre><code>
	 * {
	 *   Supported Versions: IntList
	 * }
	 * </code></pre>
	 */
	public record Handshake(IntList supportedVersions) implements CustomPacketPayload {
		public static final ResourceLocation ID = ServerPackets.id("registry_sync/handshake");

		public Handshake(FriendlyByteBuf buf) {
			this(buf.readIntIdList());
		}

		@Override
		public void write(FriendlyByteBuf buf) {
			buf.writeIntIdList(this.supportedVersions);
		}

		@Override
		public ResourceLocation id() {
			return ID;
		}
	}

	/**
	 * Ends registry sync. No data
	 */
	public record End() implements CustomPacketPayload {
		public static final ResourceLocation ID = ServerPackets.id("registry_sync/end");

		public End(FriendlyByteBuf buf) {
			this();
		}

		@Override
		public void write(FriendlyByteBuf buf) {
		}

		@Override
		public ResourceLocation id() {
			return ID;
		}
	}

	/**
	 * Sets current registry for next {@link RegistryData#ID} and {@link RegistryRestore#ID} packets.
	 *
	 * <pre><code>
	 * {
	 *   Registry identifier: Identifier
	 *   Count of entries: VarInt
	 *   Flags: byte
	 * }
	 * </code></pre>
	 */
	public record RegistryStart<T extends Registry<?>>(ResourceLocation registry, int size, byte flags) implements CustomPacketPayload {
		public static final ResourceLocation ID = ServerPackets.id("registry_sync/registry_start");

		@SuppressWarnings("unchecked")
		public RegistryStart(T registry) {
			this((((Registry<T>) BuiltInRegistries.REGISTRY).getKey(registry)), registry.size(), getFlags((SynchronizedRegistry<T>) registry));
		}

		public RegistryStart(FriendlyByteBuf buf) {
			this(buf.readResourceLocation(), buf.readVarInt(), buf.readByte());
		}

		private static <T extends Registry<?>> byte getFlags(SynchronizedRegistry<T> registry) {
			var flags = registry.quilt$getRegistryFlag();
			if (registry.quilt$getContentStatus() == SynchronizedRegistry.Status.OPTIONAL) {
				flags |= (byte) (0x1 << RegistryFlag.OPTIONAL.ordinal());
			}

			return flags;
		}

		@Override
		public void write(FriendlyByteBuf buf) {
			buf.writeResourceLocation(this.registry);
			buf.writeVarInt(this.size);
			buf.writeByte(this.flags);
		}

		@Override
		public ResourceLocation id() {
			return ID;
		}
	}

	/**
	 * This packet transmits registry data required for sync.
	 *
	 * <pre><code>
	 * {
	 *   Count of Namespaces: VarInt
	 *   [
	 *     Common Namespace: String
	 *     Count of Entries: VarInt
	 *     [
	 *       Path: String
	 *       Id: VarInt
	 *       Flags: byte
	 *     ]
	 *   ]
	 * }
	 * </code></pre>
	 */
	public record RegistryData(Map<String, ArrayList<SynchronizedRegistry.SyncEntry>> packetData) implements CustomPacketPayload {
		public static final ResourceLocation ID = ServerPackets.id("registry_sync/registry_data");

		public RegistryData(FriendlyByteBuf buf) {
			this(read(buf));
		}

		private static Map<String, ArrayList<SynchronizedRegistry.SyncEntry>> read(FriendlyByteBuf buf) {
			var data = new HashMap<String, ArrayList<SynchronizedRegistry.SyncEntry>>();
			int countNamespace = buf.readVarInt();
			while (countNamespace-- > 0) {
				var namespace = buf.readUtf();
				int countLocal = buf.readVarInt();

				while (countLocal-- > 0) {
					var path = buf.readUtf();
					int id = buf.readVarInt();
					byte flags = buf.readByte();

					data.computeIfAbsent(namespace, n -> new ArrayList<>()).add(new SynchronizedRegistry.SyncEntry(path, id, flags));
				}
			}

			return data;
		}

		@Override
		public void write(FriendlyByteBuf buf) {
			buf.writeVarInt(this.packetData.size());
			for (var key : this.packetData.keySet()) {
				var list = this.packetData.get(key);

				// Namespace
				buf.writeUtf(key);

				// Number of entries
				buf.writeVarInt(list.size());

				for (var entry : list) {
					// Path
					buf.writeUtf(entry.path());
					// Raw id from registry
					buf.writeVarInt(entry.rawId());
					// Entry flags
					buf.writeByte(entry.flags());
				}
			}
		}

		@Override
		public ResourceLocation id() {
			return ID;
		}
	}

	/**
	 * Applies changes to current registry, doesn't have any data.
	 */
	public record RegistryApply() implements CustomPacketPayload {
		public static final ResourceLocation ID = ServerPackets.id("registry_sync/registry_apply");

		public RegistryApply(FriendlyByteBuf buf) {
			this();
		}

		@Override
		public void write(FriendlyByteBuf buf) {
		}

		@Override
		public ResourceLocation id() {
			return ID;
		}
	}

	/**
	 * This packet requests client to validate ids of {@link net.minecraft.world.level.block.Block#BLOCK_STATE_REGISTRY} or {@link net.minecraft.world.level.material.Fluid#FLUID_STATE_REGISTRY} to prevent id mismatch.
	 * It might not send all states in single packet! It needs to be verified as is (aka, ids matter, count doesn't).
	 *
	 * <pre><code>
	 * {
	 *   Count of Entries: VarInt
	 *   [
	 *     Block/Fluid Id: VarInt
	 *     Count of Entries: VarInt
	 *     [
	 *       Block/Fluid State Id: VarInt
	 *     ]
	 *   ]
	 * }
	 * </code></pre>
	 */
	public record ValidateStates(StateType type, Int2ObjectArrayMap<IntList> packetData) implements CustomPacketPayload {
		public ValidateStates(StateType type, FriendlyByteBuf buf) {
			this(type, read(buf));
		}

		private static Int2ObjectArrayMap<IntList> read(FriendlyByteBuf buf) {
			Int2ObjectArrayMap<IntList> data = new Int2ObjectArrayMap<>();
			var count = buf.readVarInt();

			while (count-- > 0) {
				var blockId = buf.readVarInt();
				var states = buf.readIntIdList();
				data.put(blockId, states);
			}

			return data;
		}

		@Override
		public void write(FriendlyByteBuf buf) {
			buf.writeVarInt(this.packetData.size());
			for (var entry : this.packetData.int2ObjectEntrySet()) {
				buf.writeVarInt(entry.getIntKey());
				buf.writeIntIdList(entry.getValue());
			}
		}

		@Override
		public ResourceLocation id() {
			return this.type.packetId;
		}

		public static ValidateStates newBlock(FriendlyByteBuf buf) {
			return new ValidateStates(StateType.BLOCK, buf);
		}

		public static ValidateStates newFluid(FriendlyByteBuf buf) {
			return new ValidateStates(StateType.FLUID, buf);
		}

		public enum StateType {
			BLOCK(ServerPackets.id("registry_sync/validate/block_states")), FLUID(ServerPackets.id("registry_sync/validate/fluid_states"));

			private final ResourceLocation packetId;

			StateType(ResourceLocation packetId) {
				this.packetId = packetId;
			}

			public ResourceLocation packetId() {
				return this.packetId;
			}
		}
	}

	/**
	 * Applies changes to current registry, doesn't have any data.
	 */
	public record RegistryRestore() implements CustomPacketPayload {
		public static final ResourceLocation ID = ServerPackets.id("registry_sync/registry_restore");

		public RegistryRestore(FriendlyByteBuf buf) {
			this();
		}

		@Override
		public void write(FriendlyByteBuf buf) {
		}

		@Override
		public ResourceLocation id() {
			return ID;
		}
	}

	/**
	 * This packet sets failure text look/properties.
	 * Requires protocol version 3 or newer.
	 *
	 * <pre><code>
	 * {
	 *   Text Header: Text (String)
	 *   Text Footer: Text (String)
	 *   Show Details: bool
	 *
	 * }
	 * </code></pre>
	 */
	public record ErrorStyle(Component errorHeader, Component errorFooter, boolean showError) implements CustomPacketPayload {
		public static final ResourceLocation ID = ServerPackets.id("registry_sync/error_style");

		public ErrorStyle(FriendlyByteBuf buf) {
			this(buf.readComponent(), buf.readComponent(), buf.readBoolean());
		}

		@Override
		public void write(FriendlyByteBuf buf) {
			buf.writeComponent(this.errorHeader);
			buf.writeComponent(this.errorFooter);
			buf.writeBoolean(this.showError);
		}

		@Override
		public ResourceLocation id() {
			return ID;
		}
	}

	/**
	 * This packet requests client to validate and return supported Mod Protocol versions.
	 *
	 * <pre><code>
	 * {
	 *   Prioritized Id: String
	 *   Count of Entries: VarInt
	 *   [
	 *     Id: String
	 *     Name: String
	 *     Supported Versions: IntList
	 *     Optional: boolean
	 *   ]
	 * }
	 * </code></pre>
	 */
	public record ModProtocol(String prioritizedId, Collection<ModProtocolDef> protocols) implements CustomPacketPayload {
		public static final ResourceLocation ID = ServerPackets.id("registry_sync/mod_protocol");

		public ModProtocol(FriendlyByteBuf buf) {
			this(buf.readUtf(), buf.readList(ModProtocolDef::read));
		}

		@Override
		public void write(FriendlyByteBuf buf) {
			buf.writeUtf(this.prioritizedId);
			buf.writeCollection(this.protocols, ModProtocolDef::write);
		}

		@Override
		public ResourceLocation id() {
			return ID;
		}
	}

	private static ResourceLocation id(String path) {
		return new ResourceLocation("qsl", path);
	}
}
