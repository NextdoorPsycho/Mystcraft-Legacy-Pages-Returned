/*
 * Copyright 2023 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.registry.mixin.client;

import java.util.List;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.layouts.LayoutSettings;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.DisconnectedScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.quiltmc.loader.api.minecraft.ClientOnly;
import org.quiltmc.qsl.registry.impl.sync.client.ClientRegistrySync;
import org.quiltmc.qsl.registry.impl.sync.client.LogBuilder;
import org.quiltmc.qsl.registry.impl.sync.client.screen.SyncLogScreen;

@ClientOnly
@Mixin(DisconnectedScreen.class)
public class DisconnectedScreenMixin extends Screen {
	@Shadow
	@Final
	private LinearLayout grid;

	private List<LogBuilder.Section> quilt$extraLogs;

	protected DisconnectedScreenMixin(Component title) {
		super(title);
	}

	@Inject(method = "<init>*", at = @At("TAIL"))
	private void quilt$storeLogs(Screen parent, Component title, Component reason, CallbackInfo ci) {
		this.quilt$extraLogs = ClientRegistrySync.getAndClearCurrentSyncLogs();
	}

	@Inject(
			method = "init",
			at = @At(
				value = "INVOKE",
				target = "Lnet/minecraft/client/MinecraftClient;isMultiplayerEnabled()Z"
			)
	)
	private void quilt$addLogsButton(CallbackInfo ci) {
		if (!this.quilt$extraLogs.isEmpty()) {
			var logsButton = Button.builder(Component.translatableWithFallback("quilt.core.registry_sync.logs_button", "More Details"), (button) -> {
				this.minecraft.setScreen(new SyncLogScreen(this, this.quilt$extraLogs));
			}).build();
			// I might have committed some horrific crimes here
			var settings = this.grid.newCellSettings().paddingBottom(-5);
			this.grid.addChild(logsButton, settings);
		}
	}
}
