/*
 * Copyright 2023 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.registry.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import java.util.Map;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerStatusPinger;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.status.ClientStatusPacketListener;
import net.minecraft.network.protocol.status.ClientboundPongResponsePacket;
import net.minecraft.network.protocol.status.ClientboundStatusResponsePacket;
import org.quiltmc.loader.api.minecraft.ClientOnly;
import org.quiltmc.qsl.registry.impl.sync.mod_protocol.ModProtocolContainer;

@ClientOnly
@Mixin(ServerStatusPinger.class)
public class MultiplayerServerListPingerMixin {
	@ModifyArgs(method = "add", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/ClientConnection;connect(Ljava/lang/String;ILnet/minecraft/network/listener/ClientQueryPacketListener;)V"))
	private void quilt$attachModProtocol(Args args, ServerData entry, Runnable pinger) {
		var queryPacketListener = (ClientStatusPacketListener) args.get(2);
		args.set(2, new ClientStatusPacketListener() {
			@Override
			public void handleStatusResponse(ClientboundStatusResponsePacket packet) {
				if (packet.status().version().isPresent()) {
					var x = ModProtocolContainer.of(packet.status().version().get()).quilt$getModProtocol();
					ModProtocolContainer.of(entry).quilt$setModProtocol(x);
				}

				queryPacketListener.handleStatusResponse(packet);
			}

			@Override
			public void handlePongResponse(ClientboundPongResponsePacket packet) {
				queryPacketListener.handlePongResponse(packet);
			}

			@Override
			public void onDisconnect(Component reason) {
				queryPacketListener.onDisconnect(reason);
			}

			@Override
			public boolean isAcceptingMessages() {
				return queryPacketListener.isAcceptingMessages();
			}
		});
	}
}
