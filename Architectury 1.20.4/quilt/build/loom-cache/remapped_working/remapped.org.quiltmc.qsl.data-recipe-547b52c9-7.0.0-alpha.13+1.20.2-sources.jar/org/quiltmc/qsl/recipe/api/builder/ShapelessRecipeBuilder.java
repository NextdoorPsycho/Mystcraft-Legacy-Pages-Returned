/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.recipe.api.builder;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.core.NonNullList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.ShapelessRecipe;
import net.minecraft.world.level.ItemLike;

/**
 * Builder to build shapeless crafting recipes.
 */
public class ShapelessRecipeBuilder extends RecipeBuilder<ShapelessRecipeBuilder, ShapelessRecipe> {
	private final Set<Ingredient> ingredients = new HashSet<>();
	private CraftingBookCategory category = CraftingBookCategory.MISC;

	public ShapelessRecipeBuilder(ItemStack output) {
		this.output = output;
	}

	/**
	 * Adds an ingredient.
	 *
	 * @param ingredient the ingredient
	 * @return this builder
	 */
	public ShapelessRecipeBuilder ingredient(Ingredient ingredient) {
		this.ingredients.add(ingredient);
		return this;
	}

	/**
	 * Adds items as a single ingredient.
	 *
	 * @param items the items as ingredient
	 * @return this builder
	 * @see #ingredient(Ingredient)
	 * @see Ingredient#of(ItemLike...)
	 */
	public ShapelessRecipeBuilder ingredient(ItemLike... items) {
		return this.ingredient(Ingredient.of(items));
	}

	/**
	 * Adds the specified item tag as a single ingredient.
	 *
	 * @param tag the item tag as ingredient
	 * @return this builder
	 * @see #ingredient(Ingredient)
	 * @see Ingredient#of(TagKey) (TagKey)
	 */
	public ShapelessRecipeBuilder ingredient(TagKey<Item> tag) {
		return this.ingredient(Ingredient.of(tag));
	}

	/**
	 * Adds item stacks as a single ingredient.
	 *
	 * @param stacks the item stacks as ingredient
	 * @return this builder
	 * @see #ingredient(Ingredient)
	 * @see Ingredient#of(ItemStack...)
	 */
	public ShapelessRecipeBuilder ingredient(ItemStack... stacks) {
		return this.ingredient(Ingredient.of(stacks));
	}

	/**
	 * Sets the crafting book category of this recipe.
	 * <p>
	 * Default value is {@link CraftingBookCategory#MISC}.
	 *
	 * @param category the category
	 * @return this builder
	 */
	public ShapelessRecipeBuilder category(CraftingBookCategory category) {
		this.category = category;
		return this;
	}

	/**
	 * Builds the shapeless crafting recipe.
	 *
	 * @param id    the identifier of the recipe
	 * @param group the group of the recipe
	 * @return the shapeless crafting recipe
	 */
	public RecipeHolder<ShapelessRecipe> build(ResourceLocation id, String group) {
		this.checkOutputItem();

		if (this.ingredients.size() == 0) throw new IllegalStateException("Cannot build a recipe without ingredients.");

		NonNullList<Ingredient> ingredients = NonNullList.withSize(this.ingredients.size(), Ingredient.EMPTY);
		int i = 0;

		for (var ingredient : this.ingredients) {
			ingredients.set(i, ingredient);
			i++;
		}

		return new RecipeHolder<>(id, new ShapelessRecipe(group, this.category, this.output, ingredients));
	}
}
