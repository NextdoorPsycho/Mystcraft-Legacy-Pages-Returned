/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.recipe.impl;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipeType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.quiltmc.qsl.recipe.api.BaseRecipeHandler;

class BasicRecipeHandlerImpl implements BaseRecipeHandler {
	final RecipeManager recipeManager;
	final Map<RecipeType<?>, Map<ResourceLocation, RecipeHolder<?>>> recipes;
	final Map<ResourceLocation, RecipeHolder<?>> globalRecipes;
	private final RegistryAccess registryManager;

	BasicRecipeHandlerImpl(RecipeManager recipeManager, Map<RecipeType<?>, Map<ResourceLocation, RecipeHolder<?>>> recipes,
						   Map<ResourceLocation, RecipeHolder<?>> globalRecipes, RegistryAccess registryManager) {
		this.recipeManager = recipeManager;
		this.recipes = recipes;
		this.globalRecipes = globalRecipes;
		this.registryManager = registryManager;
	}

	@Override
	public @Nullable RecipeType<?> getTypeOf(ResourceLocation id) {
		return this.recipes.entrySet().stream()
				.filter(entry -> entry.getValue().containsKey(id))
				.findFirst()
				.map(Map.Entry::getKey)
				.orElse(null);
	}

	@Override
	public boolean contains(ResourceLocation id) {
		return this.globalRecipes.containsKey(id);
	}

	@Override
	public boolean contains(ResourceLocation id, RecipeType<?> type) {
		Map<ResourceLocation, RecipeHolder<?>> recipes = this.recipes.get(type);

		if (recipes == null) return false;

		return recipes.containsKey(id);
	}

	@Override
	public @Nullable RecipeHolder<?> getRecipe(ResourceLocation id) {
		return this.globalRecipes.get(id);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends Recipe<?>> @Nullable RecipeHolder<T> getRecipe(ResourceLocation id, RecipeType<T> type) {
		Map<ResourceLocation, RecipeHolder<?>> recipes = this.recipes.get(type);

		if (recipes == null) return null;

		return (RecipeHolder<T>) recipes.get(id);
	}

	@Override
	public Map<RecipeType<?>, Map<ResourceLocation, RecipeHolder<?>>> getRecipes() {
		return Collections.unmodifiableMap(this.recipes);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends Recipe<?>> Collection<RecipeHolder<T>> getRecipesOfType(RecipeType<T> type) {
		Map<ResourceLocation, RecipeHolder<?>> recipes = this.recipes.get(type);

		if (recipes == null) {
			return Collections.emptyList();
		}

		return recipes.values().stream().map(recipeHolder -> (RecipeHolder<T>) recipeHolder).toList();
	}

	@Override
	public @NotNull RegistryAccess getRegistryManager() {
		return this.registryManager;
	}
}
