/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.recipe.impl;

import java.util.Map;
import java.util.function.Function;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import com.google.common.collect.ImmutableMap;
import com.google.gson.JsonElement;
import org.jetbrains.annotations.NotNull;
import org.quiltmc.qsl.recipe.api.RecipeLoadingEvents;

final class RegisterRecipeHandlerImpl implements RecipeLoadingEvents.AddRecipesCallback.RecipeHandler {
	private final Map<ResourceLocation, JsonElement> resourceMap;
	private final Map<RecipeType<?>, ImmutableMap.Builder<ResourceLocation, RecipeHolder<?>>> builderMap;
	private final ImmutableMap.Builder<ResourceLocation, RecipeHolder<?>> globalRecipeMapBuilder;
	private final RegistryAccess registryManager;
	int registered = 0;

	RegisterRecipeHandlerImpl(
			Map<ResourceLocation, JsonElement> resourceMap,
			Map<RecipeType<?>, ImmutableMap.Builder<ResourceLocation, RecipeHolder<?>>> builderMap,
			ImmutableMap.Builder<ResourceLocation, RecipeHolder<?>> globalRecipeMapBuilder,
			RegistryAccess registryManager
	) {
		this.resourceMap = resourceMap;
		this.builderMap = builderMap;
		this.globalRecipeMapBuilder = globalRecipeMapBuilder;
		this.registryManager = registryManager;
	}

	private void register(RecipeHolder<?> recipeHolder) {
		Recipe<?> recipe = recipeHolder.value();
		ImmutableMap.Builder<ResourceLocation, RecipeHolder<?>> recipeBuilder =
				this.builderMap.computeIfAbsent(recipe.getType(), o -> ImmutableMap.builder());
		recipeBuilder.put(recipeHolder.id(), recipeHolder);
		this.globalRecipeMapBuilder.put(recipeHolder.id(), recipeHolder);
		this.registered++;

		if (RecipeManagerImpl.DEBUG_MODE) {
			RecipeManagerImpl.LOGGER.info("Added recipe {} with type {} in register phase.", recipeHolder.id(), recipe.getType());
		}
	}

	void tryRegister(RecipeHolder<?> recipeHolder) {
		if (!this.resourceMap.containsKey(recipeHolder.id())) {
			this.register(recipeHolder);
		}
	}

	@Override
	public void register(ResourceLocation id, Function<ResourceLocation, RecipeHolder<?>> factory) {
		// Add the recipe only if nothing already provides the recipe.
		if (!this.resourceMap.containsKey(id)) {
			var recipeHolder = factory.apply(id);

			if (!id.equals(recipeHolder.id())) {
				throw new IllegalStateException("The recipe " + recipeHolder.id() + " tried to be registered as " + id);
			}

			this.register(recipeHolder);
		}
	}

	@Override
	public @NotNull RegistryAccess getRegistryManager() {
		return this.registryManager;
	}
}
