/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.recipe.impl;

import it.unimi.dsi.fastutil.chars.Char2ObjectMap;
import it.unimi.dsi.fastutil.chars.CharArraySet;
import net.minecraft.core.NonNullList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.BlastingRecipe;
import net.minecraft.world.item.crafting.CampfireCookingRecipe;
import net.minecraft.world.item.crafting.CookingBookCategory;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.item.crafting.SmokingRecipe;
import net.minecraft.world.item.crafting.StonecutterRecipe;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public final class VanillaRecipeBuildersImpl {
	private VanillaRecipeBuildersImpl() {
		throw new UnsupportedOperationException("VanillaRecipeBuildersImpl only contains static definitions.");
	}

	public static NonNullList<Ingredient> getIngredients(String[] pattern, Char2ObjectMap<Ingredient> keys, int width, int height) {
		NonNullList<Ingredient> ingredients = NonNullList.withSize(width * height, Ingredient.EMPTY);
		var unusedKeys = new CharArraySet(keys.keySet());
		unusedKeys.remove(' ');

		for (int i = 0; i < pattern.length; ++i) {
			for (int j = 0; j < pattern[i].length(); ++j) {
				char key = pattern[i].charAt(j);
				Ingredient ingredient = keys.get(key);

				if (ingredient == null) {
					throw new IllegalStateException("Pattern references symbol '" + key + "' but it's not defined in the key");
				}

				unusedKeys.remove(key);
				ingredients.set(j + width * i, ingredient);
			}
		}

		if (!unusedKeys.isEmpty()) {
			throw new IllegalStateException("Key defines symbols that aren't used in pattern: " + unusedKeys);
		}

		return ingredients;
	}

	public static RecipeHolder<StonecutterRecipe> stonecuttingRecipe(ResourceLocation id, String group, Ingredient input, ItemStack output) {
		if (input == Ingredient.EMPTY) throw new IllegalArgumentException("Input cannot be empty.");

		return new RecipeHolder<>(id, new StonecutterRecipe(group, input, output));
	}

	public static RecipeHolder<SmeltingRecipe> smeltingRecipe(ResourceLocation id, String group, CookingBookCategory category, Ingredient input, ItemStack output, float experience, int cookTime) {
		if (input == Ingredient.EMPTY) throw new IllegalArgumentException("Input cannot be empty.");
		if (cookTime < 0) throw new IllegalArgumentException("Cook time must be equal or greater than 0");

		return new RecipeHolder<>(id, new SmeltingRecipe(group, category, input, output, experience, cookTime));
	}

	public static RecipeHolder<BlastingRecipe> blastingRecipe(ResourceLocation id, String group, CookingBookCategory category, Ingredient input, ItemStack output, float experience, int cookTime) {
		if (input == Ingredient.EMPTY) throw new IllegalArgumentException("Input cannot be empty.");
		if (cookTime < 0) throw new IllegalArgumentException("Cook time must be equal or greater than 0");

		return new RecipeHolder<>(id, new BlastingRecipe(group, category, input, output, experience, cookTime));
	}

	public static RecipeHolder<SmokingRecipe> smokingRecipe(ResourceLocation id, String group, CookingBookCategory category, Ingredient input, ItemStack output, float experience, int cookTime) {
		if (input == Ingredient.EMPTY) throw new IllegalArgumentException("Input cannot be empty.");
		if (cookTime < 0) throw new IllegalArgumentException("Cook time must be equal or greater than 0");

		return new RecipeHolder<>(id, new SmokingRecipe(group, category, input, output, experience, cookTime));
	}

	public static RecipeHolder<CampfireCookingRecipe> campfireCookingRecipe(ResourceLocation id, String group, CookingBookCategory category, Ingredient input,
			ItemStack output, float experience, int cookTime) {
		if (input == Ingredient.EMPTY) throw new IllegalArgumentException("Input cannot be empty.");
		if (cookTime < 0) throw new IllegalArgumentException("Cook time must be equal or greater than 0");

		return new RecipeHolder<>(id, new CampfireCookingRecipe(group, category, input, output, experience, cookTime));
	}
}
