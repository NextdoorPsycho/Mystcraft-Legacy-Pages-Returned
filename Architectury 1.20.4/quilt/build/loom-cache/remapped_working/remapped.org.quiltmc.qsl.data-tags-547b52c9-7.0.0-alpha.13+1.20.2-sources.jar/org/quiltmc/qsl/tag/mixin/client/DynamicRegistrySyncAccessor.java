/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.tag.mixin.client;

import java.util.Map;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistrySynchronization;
import net.minecraft.resources.ResourceKey;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.quiltmc.loader.api.minecraft.ClientOnly;

@ClientOnly
@Mixin(RegistrySynchronization.class)
public interface DynamicRegistrySyncAccessor {
	@Accessor("SYNCED_CODECS")
	static Map<ResourceKey<? extends Registry<?>>, ?> quilt$getSyncableRegistries() {
		throw new IllegalStateException("Mixin injection failed.");
	}
}
