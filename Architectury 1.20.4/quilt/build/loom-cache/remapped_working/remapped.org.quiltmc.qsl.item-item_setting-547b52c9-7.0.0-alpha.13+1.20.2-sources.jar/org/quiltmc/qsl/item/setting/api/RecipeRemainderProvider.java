/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.item.setting.api;

import net.minecraft.core.NonNullList;
import net.minecraft.world.Container;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.Nullable;

/**
 * Allows an item to conditionally specify the recipe remainder.
 * The recipe remainder is an {@link ItemStack} instead of an {@link Item}.
 * This can be used to allow your item to get damaged instead of
 * getting removed when used in crafting.
 *
 * <p>
 * Recipe remainder providers can be set with {@link QuiltItemSettings#recipeRemainder(RecipeRemainderProvider)}.
 */
@FunctionalInterface
public interface RecipeRemainderProvider {
	/**
	 * An {@link ItemStack} aware version of {@link Item#getCraftingRemainingItem()}.
	 *
	 * @param original the input item stack
	 * @param recipe the recipe being used
	 * @return the recipe remainder
	 */
	@Contract(value = "_, _ -> new")
	ItemStack getRecipeRemainder(ItemStack original, @Nullable Recipe<?> recipe);

	static NonNullList<ItemStack> getRemainingStacks(Container inventory, Recipe<?> recipe, RecipeRemainderLocation location, NonNullList<ItemStack> defaultedList) {
		for (int i = 0; i < defaultedList.size(); ++i) {
			ItemStack stack = inventory.getItem(i);
			ItemStack remainder = RecipeRemainderLogicHandler.getRemainder(stack, recipe, location);

			if (!remainder.isEmpty()) {
				defaultedList.set(i, remainder);
			}
		}

		return defaultedList;
	}
}
