/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.item.setting.mixin.recipe_remainder;

import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.world.Container;
import net.minecraft.world.Containers;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.AbstractCookingRecipe;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.quiltmc.qsl.item.setting.api.RecipeRemainderLocation;
import org.quiltmc.qsl.item.setting.api.RecipeRemainderLogicHandler;

@Mixin(AbstractFurnaceBlockEntity.class)
public abstract class AbstractFurnaceBlockEntityMixin extends BlockEntity implements WorldlyContainer {
	@Unique
	private static final ThreadLocal<AbstractFurnaceBlockEntity> quilt$THREAD_LOCAL_BLOCK_ENTITY = new ThreadLocal<>();
	@Shadow
	@Final
	protected static int FUEL_SLOT;
	@Shadow
	@Final
	protected static int INPUT_SLOT;
	@Shadow
	protected NonNullList<ItemStack> inventory;
	@Shadow
	@Final
	private RecipeManager.CachedCheck<Container, ? extends AbstractCookingRecipe> recipeCache;

	public AbstractFurnaceBlockEntityMixin(BlockEntityType<?> type, BlockPos pos, BlockState state) {
		super(type, pos, state);
	}

	// Needed some place to store the furnace entity before any remainders are checked
	@SuppressWarnings("ConstantConditions")
	@Inject(method = "isBurning", at = @At("HEAD"))
	private void setThreadLocalBlockEntity(CallbackInfoReturnable<Boolean> cir) {
		quilt$THREAD_LOCAL_BLOCK_ENTITY.set((AbstractFurnaceBlockEntity) (BlockEntity) this);
	}

	// prevent additional smelting if remainder item overflow would have no location to be dropped into the world
	@SuppressWarnings("ConstantConditions")
	@Inject(method = "canAcceptRecipeOutput", at = @At("RETURN"), cancellable = true)
	private static void checkMismatchedRemaindersCanDrop(RegistryAccess registryManager, @Nullable RecipeHolder<?> recipeHolder, NonNullList<ItemStack> inventory, int count, CallbackInfoReturnable<Boolean> cir) {
		if (cir.getReturnValue() && quilt$THREAD_LOCAL_BLOCK_ENTITY.get() == null) {
			ItemStack original = inventory.get(INPUT_SLOT).copy();

			if (!original.isEmpty()) {
				ItemStack remainder = RecipeRemainderLogicHandler.getRemainder(original, recipeHolder.value(), RecipeRemainderLocation.FURNACE_INGREDIENT).copy();
				original.shrink(1);

				if (!remainder.isEmpty() && ItemStack.isSameItemSameTags(original, remainder)) {
					int toTake = Math.min(original.getMaxStackSize() - original.getCount(), remainder.getCount());
					remainder.shrink(toTake);

					if (!remainder.isEmpty()) {
						cir.setReturnValue(false);
					}
				}
			}
		}
	}

	@SuppressWarnings("ConstantConditions")
	@Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;decrement(I)V"))
	private static void setFuelRemainder(ItemStack fuelStack, int amount, Level world, BlockPos pos, BlockState state, AbstractFurnaceBlockEntity blockEntity) {
		AbstractFurnaceBlockEntityMixin cast = ((AbstractFurnaceBlockEntityMixin) (BlockEntity) blockEntity);

		Recipe<?> recipe;
		if (!cast.inventory.get(INPUT_SLOT).isEmpty()) {
			recipe = cast.recipeCache.getRecipeFor(blockEntity, world).map(RecipeHolder::value).orElse(null);
		} else {
			recipe = null;
		}

		RecipeRemainderLogicHandler.handleRemainderForNonPlayerCraft(
				fuelStack,
				amount,
				recipe,
				RecipeRemainderLocation.FURNACE_FUEL,
				cast.inventory,
				FUEL_SLOT,
				blockEntity.getLevel(),
				blockEntity.getBlockPos()
		);
	}

	@Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/collection/DefaultedList;set(ILjava/lang/Object;)Ljava/lang/Object;"))
	private static <E> E cancelVanillaRemainder(NonNullList<E> defaultedList, int index, E element) {
		return element;
	}

	@Redirect(method = "craftRecipe", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;decrement(I)V"))
	private static void setInputRemainder(ItemStack inputStack, int amount, RegistryAccess registryManager, @Nullable RecipeHolder<?> recipeHolder, NonNullList<ItemStack> inventory, int count) {
		RecipeRemainderLogicHandler.handleRemainderForNonPlayerCraft(
				inputStack,
				amount,
				recipeHolder == null ? null : recipeHolder.value(),
				RecipeRemainderLocation.FURNACE_INGREDIENT,
				inventory,
				INPUT_SLOT,
				remainder -> { // consumer only called when there are excess remainder items that can be dropped into the world
					// block entity guaranteed not to be null here thanks to checks in canAcceptRecipeOutput injection above
					AbstractFurnaceBlockEntity be = quilt$THREAD_LOCAL_BLOCK_ENTITY.get();
					BlockPos location = be.getBlockPos();
					Containers.dropItemStack(be.getLevel(), location.getX(), location.getY(), location.getZ(), remainder);
				}
		);
	}

	@Inject(method = "tick", at = @At("RETURN"))
	private static void resetThreadLocalBlockEntity(Level world, BlockPos pos, BlockState state, AbstractFurnaceBlockEntity blockEntity, CallbackInfo ci) {
		quilt$THREAD_LOCAL_BLOCK_ENTITY.remove();
	}
}
