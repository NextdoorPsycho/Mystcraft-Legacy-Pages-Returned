/*
 * Copyright 2022 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.item.setting.mixin.recipe_remainder;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.StonecutterMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import org.quiltmc.qsl.item.setting.api.RecipeRemainderLocation;
import org.quiltmc.qsl.item.setting.api.RecipeRemainderLogicHandler;

@Mixin(targets = {"net.minecraft.screen.StonecutterScreenHandler$C_biccipxg"})
public class StonecutterOutputSlotMixin extends Slot {
	@Shadow
	@Dynamic
	StonecutterMenu field_17639;

	public StonecutterOutputSlotMixin(Container inventory, int i, int j, int k) {
		super(inventory, i, j, k);
	}

	@Redirect(method = "onTakeItem(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/item/ItemStack;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/screen/slot/Slot;takeStack(I)Lnet/minecraft/item/ItemStack;"))
	public ItemStack getRecipeRemainder(Slot slot, int amount, Player player, ItemStack stack) {
		int selectedRecipe = this.field_17639.getSelectedRecipeIndex();
		Recipe<?> recipe = selectedRecipe != -1 ? this.field_17639.getRecipes().get(selectedRecipe).value() : null;
		Item inputItem = slot.getItem().getItem();
		int inputCount = slot.getItem().getCount();

		RecipeRemainderLogicHandler.handleRemainderForScreenHandler(
				slot,
				amount,
				recipe,
				RecipeRemainderLocation.STONECUTTER_INPUT,
				player
		);

		return new ItemStack(inputItem, Math.min(amount, inputCount));
	}
}
