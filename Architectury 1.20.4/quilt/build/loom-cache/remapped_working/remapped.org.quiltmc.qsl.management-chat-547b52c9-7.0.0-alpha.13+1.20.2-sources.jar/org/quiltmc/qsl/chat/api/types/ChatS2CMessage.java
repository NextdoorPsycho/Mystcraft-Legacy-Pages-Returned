/*
 * Copyright 2023 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.chat.api.types;

import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.network.chat.ChatType;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FilterMask;
import net.minecraft.network.chat.MessageSignature;
import net.minecraft.network.chat.SignedMessageBody;
import net.minecraft.network.protocol.game.ClientboundPlayerChatPacket;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.quiltmc.qsl.chat.api.QuiltMessageType;
import org.quiltmc.qsl.chat.impl.InternalMessageTypesFactory;

/**
 * A wrapper around an S2C chat message. These are chat messages from players being relayed from the server.
 */
public class ChatS2CMessage extends AbstractChatMessage<ClientboundPlayerChatPacket> {
	private final UUID sender;
	private final int index;
	private final MessageSignature signature;
	private final SignedMessageBody.Packed body;
	private final Component unsignedContent;
	private final FilterMask filterMask;
	private final ChatType.BoundNetwork messageType;

	public ChatS2CMessage(Player player, boolean isClient, ClientboundPlayerChatPacket packet) {
		this(
				player, isClient,
				packet.sender(),
				packet.index(),
				packet.signature(),
				packet.body(),
				packet.unsignedContent(),
				packet.filterMask(),
				packet.chatType()
		);
	}

	public ChatS2CMessage(Player player, boolean isClient, UUID sender, int index, MessageSignature signature, SignedMessageBody.Packed body, Component unsignedContent, FilterMask filterMask, ChatType.BoundNetwork messageType) {
		super(player, isClient);
		this.sender = sender;
		this.index = index;
		this.signature = signature;
		this.body = body;
		this.unsignedContent = unsignedContent;
		this.filterMask = filterMask;
		this.messageType = messageType;
	}

	@Override
	public @NotNull EnumSet<QuiltMessageType> getTypes() {
		return InternalMessageTypesFactory.s2cType(QuiltMessageType.CHAT, this.isClient);
	}

	@Override
	public @NotNull ClientboundPlayerChatPacket serialized() {
		return new ClientboundPlayerChatPacket(this.sender, this.index, this.signature, this.body, this.unsignedContent, this.filterMask, this.messageType);
	}

	@Contract(pure = true)
	public UUID getSender() {
		return this.sender;
	}

	@Contract(pure = true)
	public int getIndex() {
		return this.index;
	}

	@Contract(pure = true)
	public MessageSignature getSignature() {
		return this.signature;
	}

	@Contract(pure = true)
	public SignedMessageBody.Packed getBody() {
		return this.body;
	}

	@Contract(pure = true)
	public Component getUnsignedContent() {
		return this.unsignedContent;
	}

	@Contract(pure = true)
	public FilterMask getFilterMask() {
		return this.filterMask;
	}

	@Contract(pure = true)
	public ChatType.BoundNetwork getMessageType() {
		return this.messageType;
	}

	@Contract(value = "_ -> new", pure = true)
	public ChatS2CMessage withSender(UUID sender) {
		return new ChatS2CMessage(this.player, this.isClient, sender, this.index, this.signature, this.body, this.unsignedContent, this.filterMask, this.messageType);
	}

	@Contract(value = "_ -> new", pure = true)
	public ChatS2CMessage withIndex(int index) {
		return new ChatS2CMessage(this.player, this.isClient, this.sender, index, this.signature, this.body, this.unsignedContent, this.filterMask, this.messageType);
	}

	@Contract(value = "_ -> new", pure = true)
	public ChatS2CMessage withSignature(MessageSignature signature) {
		return new ChatS2CMessage(this.player, this.isClient, this.sender, this.index, signature, this.body, this.unsignedContent, this.filterMask, this.messageType);
	}

	@Contract(value = "_ -> new", pure = true)
	public ChatS2CMessage withBody(SignedMessageBody.Packed body) {
		return new ChatS2CMessage(this.player, this.isClient, this.sender, this.index, this.signature, body, this.unsignedContent, this.filterMask, this.messageType);
	}

	@Contract(value = "_ -> new", pure = true)
	public ChatS2CMessage withUnsignedContent(Component unsignedContent) {
		return new ChatS2CMessage(this.player, this.isClient, this.sender, this.index, this.signature, this.body, unsignedContent, this.filterMask, this.messageType);
	}

	@Contract(value = "_ -> new", pure = true)
	public ChatS2CMessage withFilterMask(FilterMask filterMask) {
		return new ChatS2CMessage(this.player, this.isClient, this.sender, this.index, this.signature, this.body, this.unsignedContent, filterMask, this.messageType);
	}

	@Contract(value = "_ -> new", pure = true)
	public ChatS2CMessage withMessageType(ChatType.BoundNetwork messageType) {
		return new ChatS2CMessage(this.player, this.isClient, this.sender, this.index, this.signature, this.body, this.unsignedContent, this.filterMask, messageType);
	}

	@Override
	public String toString() {
		return "ChatS2CMessage{" + "sender=" + this.sender +
				", index=" + this.index +
				", signature=" + this.signature +
				", body=" + this.body +
				", unsignedContent=" + this.unsignedContent +
				", filterMask=" + this.filterMask +
				", messageType=" + this.messageType +
				", player=" + this.player +
				", isClient=" + this.isClient +
				'}';
	}
}
