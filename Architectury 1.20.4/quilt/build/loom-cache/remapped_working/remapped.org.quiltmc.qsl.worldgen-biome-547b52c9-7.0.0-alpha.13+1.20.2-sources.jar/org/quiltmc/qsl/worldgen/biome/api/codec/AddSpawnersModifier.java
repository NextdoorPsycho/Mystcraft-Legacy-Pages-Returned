/*
 * Copyright 2023 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.worldgen.biome.api.codec;

import java.util.List;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.MobSpawnSettings;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.quiltmc.qsl.data.callback.api.CodecHelpers;
import org.quiltmc.qsl.data.callback.api.predicate.CodecAwarePredicate;
import org.quiltmc.qsl.worldgen.biome.api.BiomeModificationContext;
import org.quiltmc.qsl.worldgen.biome.api.BiomeModifier;
import org.quiltmc.qsl.worldgen.biome.api.BiomeSelectionContext;

/**
 * A biome modifier that adds mob spawners to biomes.
 * <p>
 * The biome modifier identifier is {@code quilt:add_spawners}.
 *
 * @param spawners the spawners to add
 * @param group    the spawn group to add the spawners to; if not provided, this is determined by the spawner's entity
 *                 type's spawn group
 */
public record AddSpawnersModifier(
		CodecAwarePredicate<BiomeSelectionContext> selector,
		List<MobSpawnSettings.SpawnerData> spawners,
		Optional<MobCategory> group
) implements BiomeModifier {
	public static final ResourceLocation CODEC_ID = new ResourceLocation("quilt", "add_spawners");
	public static final Codec<AddSpawnersModifier> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			BiomeModifier.BIOME_SELECTOR_CODEC.fieldOf("selector").forGetter(AddSpawnersModifier::selector),
			CodecHelpers.listOrValue(MobSpawnSettings.SpawnerData.CODEC).fieldOf("spawners").forGetter(AddSpawnersModifier::spawners),
			MobCategory.CODEC.optionalFieldOf("group").forGetter(AddSpawnersModifier::group)
	).apply(instance, AddSpawnersModifier::new));

	@Override
	public boolean shouldModify(BiomeSelectionContext context) {
		return this.selector.test(context);
	}

	@Override
	public void modify(BiomeSelectionContext selectionContext, BiomeModificationContext modificationContext) {
		for (MobSpawnSettings.SpawnerData spawner : this.spawners) {
			modificationContext.getSpawnSettings().addSpawn(this.group.orElseGet(spawner.type::getCategory), spawner);
		}
	}

	@Override
	public ResourceLocation getCodecId() {
		return CODEC_ID;
	}
}
