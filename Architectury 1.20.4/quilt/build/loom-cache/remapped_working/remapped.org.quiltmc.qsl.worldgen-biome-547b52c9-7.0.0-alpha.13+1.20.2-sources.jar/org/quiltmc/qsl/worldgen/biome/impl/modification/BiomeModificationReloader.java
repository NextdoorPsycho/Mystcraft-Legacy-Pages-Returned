/*
 * Copyright 2023 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.qsl.worldgen.biome.impl.modification;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.core.HolderLookup;
import net.minecraft.resources.FileToIdConverter;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.ExtraCodecs;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import org.jetbrains.annotations.ApiStatus;
import org.slf4j.Logger;
import org.quiltmc.qsl.worldgen.biome.api.BiomeModifier;
import org.quiltmc.qsl.worldgen.biome.api.ModificationPhase;

@ApiStatus.Internal
public class BiomeModificationReloader {
	private static final Logger LOGGER = LogUtils.getLogger();

	private static final Gson GSON = new GsonBuilder().setLenient().create();

	private static final Codec<Pair<ModificationPhase, BiomeModifier>> CODEC = ExtraCodecs.lazyInitializedCodec(() ->
			Codec.pair(ModificationPhase.CODEC.fieldOf("phase").codec(), BiomeModifier.BIOME_MODIFIER_CODECS.createDelegatingCodec("biome modifier")));

	private final ResourceLocation resourcePath = new ResourceLocation("quilt", "biome_modifiers");

	private final Map<ResourceLocation, Pair<ModificationPhase, BiomeModifier>> listeners = new HashMap<>();

	private final Map<ResourceLocation, Pair<ModificationPhase, BiomeModifier>> combinedListeners = new HashMap<>();

	public void apply(ResourceManager resourceManager, HolderLookup.Provider provider) {
		RegistryOps<JsonElement> ops = RegistryOps.create(JsonOps.INSTANCE, provider);
		Map<ResourceLocation, Pair<ModificationPhase, BiomeModifier>> dynamicListeners = new LinkedHashMap<>();
		FileToIdConverter resourceFileNamespace = FileToIdConverter.json(this.resourcePath.getNamespace() + "/" + this.resourcePath.getPath());

		var resources = resourceFileNamespace.listMatchingResources(resourceManager).entrySet();
		for (Map.Entry<ResourceLocation, Resource> entry : resources) {
			ResourceLocation id = entry.getKey();
			ResourceLocation unwrappedIdentifier = resourceFileNamespace.fileToId(id);

			var resource = entry.getValue();
			try (var reader = resource.openAsReader()) {
				var json = GSON.fromJson(reader, JsonElement.class);
				try {
					DataResult<Pair<ModificationPhase, BiomeModifier>> result = CODEC.parse(ops, json);

					if (result.result().isPresent()) {
						var pair = result.result().get();
						dynamicListeners.put(unwrappedIdentifier, pair);
					} else {
						LOGGER.error("Couldn't parse data file {} from {}: {}", unwrappedIdentifier, id, result.error().get().message());
					}
				} catch (IllegalStateException e) {
					// We have to catch the 'java.lang.IllegalStateException: Missing tag TagKey[minecraft:worldgen/biome / minecraft:increased_fire_burnout]'
					// that can be thrown by the biome holder list codec...
					LOGGER.error("Couldn't parse data file {} from {}", unwrappedIdentifier, id, e);
				}
			} catch (IOException e) {
				LOGGER.error("Couldn't parse data file {} from {}", unwrappedIdentifier, id, e);
			}
		}

		this.updateDynamicListeners(dynamicListeners);
	}

	private void updateDynamicListeners(Map<ResourceLocation, Pair<ModificationPhase, BiomeModifier>> dynamicListeners) {
		this.combinedListeners.clear();
		this.combinedListeners.putAll(this.listeners);
		this.combinedListeners.putAll(dynamicListeners);
	}

	public Map<ResourceLocation, BiomeModifier> getCombinedMap(ModificationPhase phase) {
		return this.combinedListeners.entrySet().stream()
				.filter(entry -> entry.getValue().getFirst() == phase)
				.collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().getSecond()));
	}

	public void addModifier(ModificationPhase phase, ResourceLocation identifier, BiomeModifier modifier) {
		this.listeners.put(identifier, new Pair<>(phase, modifier));
	}
}
