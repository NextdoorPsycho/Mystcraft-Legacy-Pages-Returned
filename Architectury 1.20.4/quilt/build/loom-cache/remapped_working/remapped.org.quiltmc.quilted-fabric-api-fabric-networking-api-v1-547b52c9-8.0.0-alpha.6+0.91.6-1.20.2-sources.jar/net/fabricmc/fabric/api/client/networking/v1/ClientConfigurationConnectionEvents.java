/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 * Copyright 2024 The Quilt Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.client.networking.v1;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.impl.base.event.QuiltCompatEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientConfigurationPacketListenerImpl;
import net.minecraft.resources.ResourceLocation;

/**
 * Offers access to events related to the configuration connection to a server on a logical client.
 *
 * @deprecated
 */
@Deprecated
public final class ClientConfigurationConnectionEvents {
	/**
	 * Event indicating a connection entering the CONFIGURATION state, ready for registering channel handlers.
	 *
	 * @see ClientConfigurationNetworking#registerReceiver(ResourceLocation, ClientConfigurationNetworking.ConfigurationChannelHandler)
	 */
	public static final Event<ClientConfigurationConnectionEvents.Init> INIT = QuiltCompatEvent.fromQuilt(org.quiltmc.qsl.networking.api.client.ClientConfigurationConnectionEvents.INIT,
			init -> init::onConfigurationInit,
			invokerGetter -> (handler, client) -> invokerGetter.get().onConfigurationInit(handler, client)
	);

	/**
	 * An event called after the ReadyS2CPacket has been received, just before switching to the PLAY state.
	 *
	 * <p>No packets should be sent when this event is invoked.
	 */
	public static final Event<ClientConfigurationConnectionEvents.Ready> READY = QuiltCompatEvent.fromQuilt(org.quiltmc.qsl.networking.api.client.ClientConfigurationConnectionEvents.READY,
			init -> (handler, sender, client) -> init.onConfigurationReady(handler, client),
			invokerGetter -> (handler, client) -> invokerGetter.get().onConfigurationReady(handler, org.quiltmc.qsl.networking.impl.client.ClientNetworkingImpl.getClientConfigurationAddon(), client)
	);

	/**
	 * An event for the disconnection of the client configuration network handler.
	 *
	 * <p>No packets should be sent when this event is invoked.
	 */
	public static final Event<ClientConfigurationConnectionEvents.Disconnect> DISCONNECT = QuiltCompatEvent.fromQuilt(org.quiltmc.qsl.networking.api.client.ClientConfigurationConnectionEvents.DISCONNECT,
			init -> init::onConfigurationDisconnect,
			invokerGetter -> (handler, client) -> invokerGetter.get().onConfigurationDisconnect(handler, client)
	);

	private ClientConfigurationConnectionEvents() {
	}

	@FunctionalInterface
	public interface Init {
		void onConfigurationInit(ClientConfigurationPacketListenerImpl handler, Minecraft client);
	}

	@FunctionalInterface
	public interface Ready {
		void onConfigurationReady(ClientConfigurationPacketListenerImpl handler, Minecraft client);
	}

	@FunctionalInterface
	public interface Disconnect {
		void onConfigurationDisconnect(ClientConfigurationPacketListenerImpl handler, Minecraft client);
	}
}
